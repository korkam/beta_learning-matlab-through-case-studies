function varargout = CityName(varargin)

%This function uses the GeoNames 5000 city data to determine the name of the
%city closest to the latitude and longitude provided by the user.
%
%city = CityName(lat,lon);
%[city,country] = CityName(lat,lon);
%[city,country,missDist] = CityName(lat,lon,popThresh);
%
%city is a string naming the nearest city.  lat and long are degrees
%latitude and longitude, respectively. country is a string indicating the
%continent, country, and urband area.  missDist is the distance between the
%provided coordinates and city center in km. popThresh is a population
%threshold.  Only cities with populations above threshold will be
%considered.  

%Richard Moore
%May 2, 2016

%The struct used by this function is in the accompanying .mat file, but it
%can be rebuilt from the GeoNames text file with the code below:
% s = tdfread('cities5000.txt');
% s.lon = s.x10x2E49129;
% s.lat = s.x420x2E46372;
% s.name = s.Sant_Julia_de_Loria;
% s.country = s.Europe0x2FAndorra;
% s.pop = s.x8022;

lat = varargin{1};
lon = varargin{2};
if nargin>2
    popThresh = varargin{3};
end

load('CityStruct.mat');

radEarth = 6371; %in km

while lon>180
    lon = lon - 360;
end

while lon<-180
    lon = lon + 360;
end

latErrs = abs(t.lat-lat);
lonErrs = abs(t.lon-lon);
%Here's the old euclidean distance in just lat lon.
%totErr = (latErrs.^2+lonErrs.^2).^0.5;
%Here's an improved distance calculation (which still assumes a spherical
%earth, though).  
latDists = deg2rad(latErrs).*radEarth;
lonDists = cos(deg2rad(latErrs)).*deg2rad(lonErrs).*radEarth;
totErr =  (latDists.^2+lonDists.^2).^0.5;%Now in km.  Earth assumed spherical.

if exist('popThresh')
    totErr(t.pop<popThresh) = inf;
end
[minErr,minInd] = min(totErr);

strOut = [t.name(minInd,:)];
varargout{1} = strOut;

%Pass the extra output arguments if expected:
if nargout>1
    varargout{2} = t.country(minInd,:);
end
if nargout>2
    varargout{3} = minErr;
end