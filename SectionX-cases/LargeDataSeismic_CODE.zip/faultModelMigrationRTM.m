%% Seismic Migration Example - Fault Model
%% Data source
% This example is derived from Gerard Schuster's
% <http://utam.gg.utah.edu/Inter.LAB1/CH2.lab/lab.mig.pre/lab.html MATLAB
% example> and book <http://www.cambridge.org/gb/knowledge/isbn/item2327397/?site_locale=en_GB
% Seismic Interferometry>
%
addpath faultModelData
addpath migration

%% Read in velocity model data and plot it
load velocityModel
[nz,nx] = size(velocityModel);

dx = 10;
dz = 10;
x = (1:nx)*dx;
z = (1:nz)*dz;

subplot(2,2,1)
imagesc(x,z,velocityModel)
xlabel('Distance (m)'); ylabel('Depth (m)');
title('Velocity Model');
hold on
hshot = plot(x(1),z(1),'w*');
hold off
colormap(seismic)

%% Create shot gathers
% Use the velocity model to simulate a seismic survey.  The wave equations
% is solved using finite differences for a defined initial wavefield.

% calculate time step dt from stability crierion for finite difference
% solution of the wave equation.
dt = 0.9*min(min(dz./velocityModel/sqrt(2)));

% determine time samples nt from wave travelime to depth and back to
% surface
vmin = min(velocityModel(:));
nt = round(sqrt((dx*nx)^2 + (dz*nx)^2)*2/vmin/dt + 1);
t  = (0:nt-1).*dt;

% add region around model for applying absorbing boundary conditions (20
% nodes wide)
V = [repmat(velocityModel(:,1),1,20) velocityModel repmat(velocityModel(:,end),1,20)];
V(end+1:end+20,:) = repmat(V(end,:),20,1);

% Define frequency parameter for ricker wavelet
f  = 20;

%% Generate shots and save to file and video

%vidObj = VideoWriter('videos\FaultModelShots.avi');
%open(vidObj);
data = zeros(size(nt,nx));
figure(gcf)
for ixs = 21:nx+20 % shot loop
    % initial wavefield
    rw = ricker(f,nz+40,dt,dt*ixs,0);
    rw = rw(1:nz+20,:);
    
    % plot initial wavefield
    set(hshot,'XData',x(ixs-20),'YData',z(1));
    subplot(2,2,2)
    imagesc(x,z,rw(1:end-20,21:end-20))
    xlabel('Distance (m)'); ylabel('Depth (m)');
    title(['Shot ',num2str(ixs-20),' at ',num2str(x(ixs-20)),' m']);
    colormap(seismic)
    
    % generate shot record
    tic
    [data snapshot] = fm2d(V,rw,nz,dz,nx,dx,nt,dt);
    toc
    %save(['faultModelData\snapshot',num2str(ixs-20),'.mat'],'snapshot');
    %save(['faultModelData\shotfdm',num2str(ixs-20),'.mat'],'data')
    
    data = data(21:end-20,:)';
    
    if ismember(ixs-20,[1 nx/2 nx])
        start = 1;
    else
        start = nt;
    end
    
    for i = start:nt
        % plot shot record evolution
        ds = zeros(nt,nx);
        ds(1:i,:) = data(1:i,:);
        subplot(2,2,3)
        imagesc(x,t,ds)
        xlabel('Distance (m)'), ylabel('Time (s)')
        title('Shot Record')
        caxis([-0.1 0.1])
        
        % plot wave propagation
        subplot(2,2,4)
        imagesc(x,z,snapshot(1:end-20,21:end-20,i))
        xlabel('Distance (m)'), ylabel('Depth (m)')
        title(['Wave Propagation t = ',num2str(t(i),'%10.3f')])
        caxis([-0.14 1])
        
        %writeVideo(vidObj,getframe(gcf));
        drawnow;
    end %shot loop
end
%close(vidObj);

%% Traveltime by 2D ray-tracing
% Generate the traveltime field for all z = 0 locations
%vidObj = VideoWriter('FaultModelTravelTime.avi');
%open(vidObj);
travelTime = zeros(nz,nx,nx);
subplot(2,2,2)
for ixs = 1:nx
    travelTime(:,:,ixs) = ray2d(velocityModel,[1 ixs],dx);
    imagesc(x,z,travelTime(:,:,ixs))
    xlabel('Distance (m)'), ylabel('Depth (m)')
    title(['Traveltime for shot ',num2str(ixs)])
    set(hshot,'XData',x(ixs));
    drawnow
    %writeVideo(vidObj,getframe(gcf));
end
%close(vidObj)
%save results for later re-use
%save('faultModelData\travelTime.mat', 'travelTime')

%% Process Shots - Kirchhoff Migration

%vidObj = VideoWriter('videos\FaultModelKirchhoff.avi');
%open(vidObj);
load('travelTime.mat');
Stacked = zeros(nz,nx);
figure(gcf)
colormap  seismic %bone
for ixs = 1:nx
    load(['shotfdm',num2str(ixs),'.mat'])
    shot = data(21:end-20,:)';
    M = migrate(travelTime,shot,dt,nz,ixs,nx);
    Stacked = Stacked + M;
    
    subplot(2,2,2)
    imagesc(x,z,Stacked)
    xlabel('Distance (m)'); ylabel('Depth (m)');
    title('Stacked Image');
    caxis([-135 135])
    
    subplot(2,2,3)
    imagesc(x,t,shot)
    xlabel('Distance (m)'); ylabel('Time (s)');
    title(['Current Shot ',num2str(ixs)]);
    caxis([-0.1 0.1])
    
    subplot(2,2,4)
    imagesc(x,t,M)
    xlabel('Distance (m)'); ylabel('Time (s)');
    title(['Current Migrated Shot ',num2str(ixs)]);
    caxis([-5 5])
    
    set(hshot,'XData',x(ixs));
    
    drawnow
    %writeVideo(vidObj,getframe(gcf));
end
%close(vidObj);

%% Process Shots - Reverse Time Migration

%vidObj = VideoWriter('videos\FaultModelRTM.avi');
%open(vidObj);
Stacked = zeros(nz+20,nx+40);
colormap seismic %bone
for ixs = 1:nx
    load(['shotfdm',num2str(ixs),'.mat'])
    shot = data(21:end-20,:)';
    
    tic
    [~, rtmsnapshot] = rtm2d(V,data,nz,dz,nx,dx,nt,dt);
    toc
    %save(['faultModelData\rtmsnapshot',num2str(ixs),'.mat'],'rtmsnapshot');
    
    load(['snapshot',num2str(ixs),'.mat']);
    
    M = 0;
    s2 = 0;
    for i = 1:nt
        M = snapshot(:,:,i).*rtmsnapshot(:,:,nt-i+1)+M;
        s2 = snapshot(:,:,i).^2+s2;
        
        if ismember(ixs,[1 nx/2 nx])
            subplot(2,2,3)
            imagesc(x,z,snapshot(1:end-20,21:end-20,i))
            xlabel('Distance (m)'); ylabel('Depth (m)');
            title(['Forward Time Wave Propagation t = ',num2str(t(i),'%10.3f')])
            caxis([-0.14 1])
            
            subplot(2,2,4)
            imagesc(x,z,rtmsnapshot(1:end-20,21:end-20,nt-i+1))
            xlabel('Distance (m)'); ylabel('Depth (m)');
            title('Reverse Time Wave Propagation')
            caxis([-0.14 1])
            
            subplot(2,2,2)
            imagesc(x,z,diff(M(1:end-20,21:end-20)./s2(1:end-20,21:end-20),2,1))
            xlabel('Distance (m)'); ylabel('Depth (m)');
            title(['Current Migrated Shot ',num2str(ixs)]);
            caxis([-.05 .05])
            
            drawnow
            %writeVideo(vidObj,getframe(gcf));
        end 
    end
    
    Stacked = Stacked + M;
    subplot(2,2,2)
    imagesc(x,z,diff(Stacked(1:end-20,21:end-20),2,1))
    xlabel('Distance (m)'); ylabel('Depth (m)');
    title('Stacked Image');
    caxis([-30 30])

    subplot(2,2,3)
    imagesc(x,t,shot)
    xlabel('Distance (m)'); ylabel('Time (s)');
    title(['Current Shot ',num2str(ixs)]);
    caxis([-0.1 0.1])
    
    subplot(2,2,4)
    imagesc(x,t,diff(M(1:end-20,21:end-20),2,1))
    xlabel('Distance (m)'); ylabel('Time (s)');
    title(['Current Migrated Shot ',num2str(ixs)]);
    caxis([-1 1])
    
    set(hshot,'XData',x(ixs));    
    drawnow
    %writeVideo(vidObj,getframe(gcf));
end
%close(vidObj);