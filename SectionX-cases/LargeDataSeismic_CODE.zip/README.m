%% Large Data in MATLAB: A Case Study in Seismic Data Processing
% These are the files used in the webinar on Feb. 23, 2011.  This file
% provides a brief description of the contents of the demo files and the
% steps needed to download the public data sources for use with this demo.
% You can watch the archived version of this webinar at
% <http://www.mathworks.com/wbnr53777>
%% Data Sources
% Two sources of data are used.  
%
% The fault model is a slice from an SEG/EAGE model which was take from
% <http://utam.gg.utah.edu/Inter.LAB1/CH2.lab/lab.mig.pre/lab.html>.
% The velocity model is needed to run |faultModelMigration.m|.
%
% The salt tooth model is from the BP Benchmark data set from:
% <http://software.seg.org/datasets/2D/2004_BP_Vel_Benchmark>
%
% You will need to download the BP Benchmark files to run the
% |saltModelMigrationRTM.m| and |migrateExample.m| files.
%
%% Required Products and Hardware
% MATLAB.  You will also need Parallel Computing Toolbox and MATLAB
% Distributed Computing Server if you want to speed up computations using
% multiple MATLAB Workers (on a multicore desktop or across a cluster of
% computers) or run the GPU example.  This demo was developed and tested on
% R2010b.
%
% For the GPU examle, you will need a supported GPU.  Consult
% <http://www.mathworks.com/products/parallel-computing/requirements.html>
% to determine if your hardware is supported.
%% Run |setup.m|
% The script |setup.m| will create the directories needed and download the
% data from the public sources.  It will also generate the 20GB
% traveltime.data file used once all the data has completed downloading.
% This can take several hours, depending upon your network connection and
% computer.  It is recomended to run this script when you don't need your
% computer for several hours (or run overnight).  Once this completes, you
% will be able to run the demos.
%% Parallel Computing Setup
% |migrateExample.m| uses parallel computing to run the migration.  If you
% don't use parallel computing, it will run for 2-3 days, or more if
% depending upon your machine.  To set up parallel computing, consult the
% doc.  You will also need to change the |matlabpool| call in
% |migrateExample.m| to point to your resources.
%% GPU Setup
% You will need to compile the CUDA kernels (*.cu files in gpu directory).
% Assuming your system is configured correctly, you can run the
% |build.m| file to compile and test the kernels are working correctly.
%% Recommended Demo Order
% To get the most out of this example.  Run these demos in this order:
%
% * |faultModelMigrationRTM.m|
% * |migrateExample.m| migration with parallel computing>
% * |saltModelMigrationRTM.m| salt model on GPU
%
% You should first uncomment the sections of code that save videos if you
% want them created.
%% Directory and File Listing
% Listing of directories and files, post run of the demo files.
%
% Top level directory (LargeDataSeismic)
dir
%%
% Benchmark data directory
dir benchmark
%%
% faultModelData directory stores the intermediate results generated from
% |faultModelMigrationRTM.m|.
dir faultModelData
%%
% fileReader directory contains the SEG Y file reader object used to read
% SEGY files in benchmark folder.  Note that these fileReaders have not
% been fully tested against SEGY/SEGD/SEG2 specifications.  No gurantees
% are provided that they work on all SEGx formatted files.
dir fileReader
%%
% gpu directory contains the files used to speed up computations usin a
% GPU.
dir gpu
%%
% Migration routines and utillity functions
dir migration
%%
% saltToothModelData directory stores intermediate results generated from
% |saltModelMigrationRTM.m|.
dir saltToothModelData
%%
% videos contains videos generated from results
dir videos

