%% Using LinearModel for Stepwise Regression
% Copyright (c) 2012, The MathWorks, Inc.

%%  Load the dataset

% Boston Housing Dataset taken from the CMU StatLib archive:  
% http://lib.stat.cmu.edu/datasets/boston

Housing = dataset('xlsfile', 'Housing.xlsx');

%% Convert CharlesRiver to a nominal variable
Housing.CharlesRiver = nominal(Housing.CharlesRiver);

%% Generate a regression
myFit = LinearModel.fit(Housing);
disp(myFit)

%% Apply stepwise regression

myFit2 = LinearModel.stepwise(Housing);
disp(myFit2)

%% Stepwise regression options
myFit3 = LinearModel.stepwise...
    (Housing, 'Upper', 'linear', 'Criterion', 'aic')


