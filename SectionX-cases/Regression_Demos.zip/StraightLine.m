%% Using LinearModel for Linear Regression - Lines and Planes
% Copyright (c) 2012, The MathWorks, Inc.

%% Clean up

rng(2010)
clear all
clc


%% Generate some data

X = linspace(1,100, 50);
X = X';
Y = 5*X + 50;
Y = Y + 20*randn(50,1);

% Create a scatterplot
scatter(X,Y, 'filled')
xlabel('X')
ylabel('Y')

%% Generate a fit

myFit = LinearModel.fit(X,Y);

%% Visualize the results

plot(myFit)

%% Change the marker style

plot(myFit, 'marker' ,'o',  'MarkerFaceColor','b')

%% Work with the fit - Prediction

Estimate = predict(myFit, 50);
disp(Estimate)

%% Display the fit

disp(myFit)

%% See the complete set of methods

methods(myFit)

%% Plot residuals versus fitted value

plotResiduals(myFit,'fitted', 'marker' ,'o',  'MarkerFaceColor','b')

%% Plot residuals versus lagged residuals

plotResiduals(myFit,'lagged', 'marker' ,'o',  'MarkerFaceColor','b')

%% See all the options for plotResiduals

help plotResiduals

%% Check whether the residuals are normally distributed

plotResiduals(myFit, 'probability', 'marker' ,'.')

%% Use Plot Diagnostics to look for outliers

plotDiagnostics(myFit, 'cookd', 'marker' ,'o',  'MarkerFaceColor','r')

%% Show how to "walk" the LinearModel object

%% Surface Fitting:  Fitting a plane

X1 = randn(100,1);
X2 = randn(100,1);

Y = 5 + 7*X1 + 9*X2 + 3*randn(100,1);

myFit = LinearModel.fit([X1 X2], Y);
disp(myFit)

%% Fitting a Hyperplane

X1 = randn(100, 1);
X2 = randn(100, 1);
X3 = randn(100,1);
X4 = randn(100,1);

Y = 3 + 5*X1 + 7*X2 + 9*X3 + 11*X4 + randn(100,1);

myFit = LinearModel.fit([X1,X2,X3,X4], Y)




