%% Using LinearModel for Linear Regression - Curve and Surfaces
% Copyright (c) 2012, The MathWorks, Inc.

%% Load data

clear all
clc
load census
scatter(cdate, pop, '.')
xlabel('Population')
ylabel('Census Date')
%%  Fit a quadratic to the data

myFit = LinearModel.fit(cdate, pop, 'quadratic');
disp(myFit)

%% Generate a line plot
plot(myFit, 'marker' ,'o',  'MarkerFaceColor','b')
xlabel('Population')
ylabel('Census Date')

%% Fit a quadratic to the data (option 2)

myFit = LinearModel.fit(cdate, pop, 'poly2');
disp(myFit)

%% Fit a quadratic to the data (option 3)

myFit = LinearModel.fit(cdate, pop, 'y ~ 1 + x1 + x1^2');
disp(myFit)

%%  High order multivariate example

X1 = randn(100,1);
X2 = randn(100,1);

Y = 1 + 3*X1.^3 + 5*X1.^2.*X2 + 7*X1.*X2.^2 + 9*X1.^2 + 11*X2.^2 ...
    + 13*X1.*X2 + 15*X1 + 17*X2 + + 19*X2.^3 + 5*randn(100,1);

%% Using "Poly33"

myFit2 = LinearModel.fit([X1, X2], Y, 'Poly33');
disp(myFit2)

%% Specifying the complete model

myFit2 = LinearModel.fit([X1,X2], Y, ...
    'y ~ x1^2 + x1*x2 + x2^2 + x1^3 + (x1^2):x2 + x1:(x2^2) + x2^3')

%% Advanced Manuever with Wilkinson notation

myFit3 = LinearModel.fit([X1, X2], Y, ...
    'y ~ x1^3*x2^3 - x1^2*x2^2')


