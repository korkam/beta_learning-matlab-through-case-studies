%%  Load the dataset

% Boston Housing Dataset taken from the CMU StatLib archive:  
% http://lib.stat.cmu.edu/datasets/boston

% Import the file into Excel using Tab deliminated format.
% Use the first row of information to define column headers from the list
% provided

% The dataset command will work fine without column headers, but
% easy-to-remember variable names make it much easier to understand what's
% happening during the analysis.

Housing = dataset('xlsfile', 'Housing.xlsx');

%% Convert CharlesRiver to a nominal variable
Housing.CharlesRiver = nominal(Housing.CharlesRiver);

%% Generate a regression
myFit = LinearModel.fit(Housing);
disp(myFit)

%% Apply stepwise regression

myFit2 = LinearModel.stepwise(Housing);
disp(myFit2)

%% Stepwise regression options
myFit3 = LinearModel.stepwise...
    (Housing, 'Upper', 'linear', 'Criterion', 'aic')


