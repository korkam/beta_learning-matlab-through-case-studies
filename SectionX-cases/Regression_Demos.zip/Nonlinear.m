%% Using NonLinearModel for Nonlinear Regression 
% Copyright (c) 2012, The MathWorks, Inc.

%% Generate some data

X = 2* pi*rand(100,1);
X = sortrows(X);

Y = 9 + 7*sin(1*X + 3);
Y = Y + randn(100,1);

scatter(X,Y)

%%  Generate a fit

% Note that we need to pass three sets of input arguments to NonLinearModel
% # The X and Y data
% # A string describing our model
% # Starting conditions for the optimization solvers

myFit = NonLinearModel.fit(X,Y, 'y ~ b0 + b1*sin(b2*x1 + b3)', [9, 7, 1, 3]);
disp(myFit)

%% look at the complete set of methods

methods(myFit)

%% Generate a plot

hold on
plot(X, myFit.Fitted)
hold off

%% Generate a fit using an alternative syntax

myFit2 = NonLinearModel.fit(X,Y, @(b,x)(b(1) + b(2)*sin(b(3)*x + b(4))), [9, 7, 1, 3])
