function LetItSnow

%Richard Moore
%December 5, 2012

v = 5; %pixel shift per frame
vstd = 1; %standard deviation of the flake velocities
vstd2 = 2;
rotstd = 8;
n = 20; %number of flakes
screenwidth = 500;
screenheight = 300;
resizefact = 0.0625;

rows = ceil((100+screenheight).*rand(n,1));
cols = ceil(100+screenwidth.*rand(n,1));
vels = 1 + rand(n,1).*vstd;
vels2 = 0 + (rand(n,1)-0.5).*vstd2;
rots = 0 + (rand(n,1)-0.5)*rotstd;

%Make a large frame.  Place the resized flakes.  Then crop.

sky = zeros(screenheight+200, screenwidth+200);
for x = 1:n
    flake{x} = SnowFlakes(4);
    smallflake = imresize(flake{x},resizefact);
    sky(rows(x):(-1+rows(x)+size(smallflake,1)),cols(x):(-1+cols(x)+size(smallflake,2))) = smallflake + sky(rows(x):(-1+rows(x)+size(smallflake,1)),cols(x):(-1+cols(x)+size(smallflake,2)));
end

z = 0;
figure;
%Still need to handle flakes leaving the frame.
%Also need to add more flakes entering from the top.
while z>-1
    z = z + 1;
    sky = zeros(screenheight+200, screenwidth+200);
    rows = rows + round(vels);
    cols = cols + round(vels2);
    for x = 1:n
        %flake{x} = SnowFlakes(4);
        smallflake = imresize(flake{x},resizefact);
        sky(rows(x):(-1+rows(x)+size(smallflake,1)),cols(x):(-1+cols(x)+size(smallflake,2))) = imrotate(smallflake,z*rots(rem(x,60)),'bilinear','crop') + sky(rows(x):(-1+rows(x)+size(smallflake,1)),cols(x):(-1+cols(x)+size(smallflake,2)));
        if (rows(x)>size(sky,1)-1.5*size(smallflake,1))||(cols(x)<20)||(cols(x)>(size(sky,2)-100))
            rows(x) = 1;
            cols(x) = ceil(rand(1)*screenwidth);
            flake{x} = SnowFlakes(4);
        end
    end
    imshow(sky(100:(end-100),100:(end-100)),[0 1.5]);
    drawnow;
end

end
%%
function imout = SnowFlakes(maxT)
%SnowFlakes.m

%Richard Moore
%December 3, 2012

t = 0;
helper = 0.55;
while t<maxT
    t = t + 1;
    flake{t} = round(helper.*rand(2^t,2^t));
    
end

%Possibly make an equilateral triangle with triangular "pixels".  Randomly
%discard some triangles and then prune away the "detached" bits.  This also
%lends itself well to operation at different scales.

%The pruned equilateral triangle should be symmetrical along an axis.

%Okay.  Now that I am producing the flake matrix, I need to write the
%portion that will turn that into a sparse and symmetrical equilateral
%triangle which can then be rotated to make a snowflake.

halfEquilateralOut = BuildFromFlake(flake);
imout = SpinAndSum(halfEquilateralOut);

    function out = BuildFromFlake(flake)
        %This will be the tricky one.
        unpruned = SumTriangles(flake);
        out = PruneTriangles(unpruned);
        
        function unpruned = SumTriangles(flake)
            %I need to be able to draw triangles using row and diagonal indices
            unpruned = zeros(601,601);
            [X Y1] = meshgrid([-300:1:300],[-300:1:300]);
            Y2 = imrotate(Y1,-60,'crop','bilinear');
            Y3 = imrotate(Y1,60,'crop','bilinear');
            for a = 16:-1:1
                UpperLimsY1(1:a,1:a) = a;
            end
            for a = 1:16
                ind1vect = [1:a a.*ones(1,a-1)];
                ind2vect = fliplr(ind1vect);
                counter = 0;
                for b = 1:numel(ind1vect)
                    counter = counter + 1;
                    UpperLimsY2(ind1vect(b),ind2vect(b)) = ceil(counter/2);
                end
            end
            UpperLimsY3 = UpperLimsY2';
            
            %keyboard;
            for x = 1:numel(flake)
                for y = 1:size(flake{x},1)
                    for z = 1:size(flake{x},2)
                        triSize = 2.^(8-x);
                        if flake{x}(y,z)==1
                            unpruned(find((Y1<=triSize*UpperLimsY1(y,z))&(Y2<=triSize*UpperLimsY2(y,z))&(Y3<=triSize*UpperLimsY3(y,z))&(Y1>triSize*(UpperLimsY1(y,z)-1))&(Y2>triSize*(UpperLimsY2(y,z)-1))&(Y3>triSize*(UpperLimsY3(y,z)-1)))) = 1;
                        end
                    end
                end
            end
            
            %Now I should be able to pick a step size and color by indices.
            %unpruned = 1;
        end
        function out = PruneTriangles(unpruned)
            %This is where the adjacency business will be used.
            out = unpruned;
        end
    end

    function out = SpinAndSum(halfEquilateralOut)
        bookmatched = ((halfEquilateralOut + fliplr(halfEquilateralOut)));
        bookmatched(find(bookmatched>0.5)) = 1;
        bookmatched2 = bookmatched + flipud(bookmatched);
        out = bookmatched2 + imrotate(bookmatched2,60,'crop','bilinear') + imrotate(bookmatched2,-60,'crop','bilinear');
        out(find(out>0.5)) = 1;
    end
end
