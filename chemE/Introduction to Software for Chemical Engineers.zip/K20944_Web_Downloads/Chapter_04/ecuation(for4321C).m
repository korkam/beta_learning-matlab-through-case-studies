function [c,f,s]=ecuation(x,t,u,DuDx)

c=998*4.18*0.5*(1-(x/0.0254)^2)/0.1;% (C)
f=DuDx;%flow term (F)
s=0;%source term (S)
