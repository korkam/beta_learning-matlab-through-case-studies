clear all;
x=linspace(0,.0254,50);%We use 50 values from 0 to 0.0254 
t=linspace(0,0.5,4);%We used 60 points from 0 and 0.5 
m=0;

sol=pdepe(m,@ecuation,@initialcond,@boundary,x,t);
u=sol(:,:,1);

% We use a surface plot 
surf(x,t,u)    
colormap([gray])
xlabel('r (m)')
ylabel('L (m)')
zlabel('T (K)')

shading interp

Figure

for j=1:length(t)
    plot(x,u(j,:),'k')
    xlabel('r (m)')
    ylabel('T (k)')
    hold on
end
