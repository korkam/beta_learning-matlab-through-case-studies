clear all;
x=linspace(0,.01,50);%We use 50 values from 0 to 0.01 
t=linspace(0,1,60);%We used 60 points from 0 to 1 
m=0;

sol=pdepe(m,@ecuation,@initialcond,@boundary,x,t)
u=sol(:,:,1);

 
% Surface plot command and data
surf(x,t,u)    
colormap([gray])
xlabel('\delta (m)')
ylabel('L (m)')
zlabel('C_a (M)')

shading interp

figure
for j=1:length(t)
    plot(x,u(j,:),'k')
    xlabel('\delta (m)')
    ylabel('C_a (M)')
    hold on
end
