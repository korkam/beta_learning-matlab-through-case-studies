%Initial conditions.
function u0=initialcond(x)
u0=0;
