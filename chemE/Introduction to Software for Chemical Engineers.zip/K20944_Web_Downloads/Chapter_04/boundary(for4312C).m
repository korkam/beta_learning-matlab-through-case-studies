function [pl,ql,pr,qr]=boundary(xl,ul,xr,ur,t)
%For r = 0
pl=0;
ql=1;
%%For r = R
pr=-100;
qr=-0.1;
