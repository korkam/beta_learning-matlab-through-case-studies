function [c,f,s]=ecuation(x,t,u,DuDx)

c=2*0.5*((x/0.01)-0.5*(x/0.01)^2)/2.1e-5;%term (C)
f=DuDx;%Flow term (F)
s=0;%source term (S)
