%Boundary conditions.
function [pl,ql,pd,qd]=boundary(xl,ul,xd,ud,t)
%for  y = 0
pl=0;
ql=1;
%%for  y = ?
pd=ud-.1;
qd=0;
