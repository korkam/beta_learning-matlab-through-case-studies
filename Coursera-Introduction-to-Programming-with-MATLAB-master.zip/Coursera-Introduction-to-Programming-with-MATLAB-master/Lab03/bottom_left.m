function v = bottom_left( M,n )
%BOTTOM_LEFT Summary of this function goes here
%   Detailed explanation goes here
v=M(end-n+1:end,1:n);
end

