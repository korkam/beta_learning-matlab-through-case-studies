function H =hulk(v)
%HULK Summary of this function goes here
%   Detailed explanation goes here
     H = [v' (v').^2 (v').^3];
end

