function Ans = rich( v )
%RICH Summary of this function goes here
%   Detailed explanation goes here
Ans=v(1)*1 + v(2)*5 + v(3)*10 + v(4)*25;
Ans=Ans/100;
end

