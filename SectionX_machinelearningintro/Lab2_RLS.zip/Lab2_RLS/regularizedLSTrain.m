function w = regularizedLSTrain(X, Y, lambda)
% RLS train
%
%  X: the (N x D) training data matrix
%  Y: the (N x 1) training output/label vector
%  lambda: regularization parameter
%
%  w: the (D x 1) vector of RLS coefficients

[N, D] = size(X);

w = []; % COMPLETE CODE: set value for w; check the "backslash" command, type "help \"

end