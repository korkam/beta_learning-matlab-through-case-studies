%% Linear algebra, signal processing, and wavelets. A unified approach. Matlab notebooks
% 
% Author: Øyvind Ryan
% 
% Date: Feb 17, 2016
% 
%%
m = 3;
[x, fs] = audioread('sounds/castanets.wav');
% 
%% Example 5.18
% 
DWTImpl([ones(512,1); zeros(512,1)], 10, @DWTKernelHaar)
% 
% 
% 
%% Exercise 5.18
% 
[x, fs] = audioread('sounds/castanets.wav');
newx = DWTImpl(x(1:2^17,1), 2, @DWTKernelHaar);
plot(newx(1:2^17,1))
axis([0 2^17 -1 1]);
% 
%% Exercise 5.23
% 
DWTImpl(repmat([1; -1],512,1), 10, @DWTKernelHaar)
% 
% 
%% Example 5.37
% 
playDWT(m, @DWTKernelHaar, @IDWTKernelHaar, 1);
playDWT(m, @DWTKernelpwl0, @IDWTKernelpwl0, 1);
playDWT(m, @DWTKernelpwl2, @IDWTKernelpwl2, 1);
% 
%% Exercise 5.34
% 
playDWT(m, @DWTKernelHaar, @IDWTKernelHaar, 0);
playDWT(m, @DWTKernelpwl0, @IDWTKernelpwl0, 0);
playDWT(m, @DWTKernelpwl2, @IDWTKernelpwl2, 0);
% 
%% Exercise 5.31a.
% 
A = zeros(2);
b = zeros(2, 1);
for k = 0:1
A(k + 1, :) = [quad(@(t)t.^k.*(1 - abs(t)), -1, 1)...
quad(@(t)t.^k.*(1 - abs(t - 1)), 0, 2)];
b(k + 1) = quad(@(t)t.^k.*(1 - 2*abs(t - 1/2)), 0, 1);
end
A\b;
% 
%% Exercise 5.31b.
% 
A = zeros(4);
b = zeros(4, 1);
for k = 0:3
A(k + 1, :) = [quad(@(t)t.^k.*(1 - abs(t)), - 1, 1)...
quad(@(t)t.^k.*(1 - abs(t - 1)), 0, 2)...
quad(@(t)t.^k.*(1 - abs(t + 1)), -2, 0)...
quad(@(t)t.^k.*(1 - abs(t - 2)), 1, 3)];
b(k + 1) = quad(@(t)t.^k.*(1 - 2*abs(t - 1/2)), 0, 1);
end
coeffs=A\b;
% 
%% Exercise 5.31c.
% 
t=linspace(-2,3,100);
plot(t, ( t>= 0).*(t <= 1).*(1-2*abs(t - 0.5)) ...
-coeffs(1)*(t >= -1).*(t <= 1).*(1 - abs(t))...
-coeffs(2)*(t >= 0).*(t <= 2).*(1 - abs(t - 1))...
-coeffs(3)*(t >= -2).*(t <= 0).*(1 - abs(t + 1))...
-coeffs(4)*(t >= 1).*(t <= 3).*(1 - abs(t - 2)))
% Exercise 6.1.10a
g1=IDWTImpl([-coeffs(1);-coeffs(2);-coeffs(4);0;0;0;0;-coeffs(3);...
1; 0; 0; 0; 0; 0; 0; 0], 1, @IDWTKernelpwl0, 0);
g1 = [g1(14:16); g1(1:6)]; % Compact filter notation
% 
% 
% 
%% Exercise 6.10a.
% 
g1=IDWTImpl([-coeffs(1);-coeffs(2);-coeffs(4);0;0;0;0;-coeffs(3);...
1; 0; 0; 0; 0; 0; 0; 0], 1, @IDWTKernelpwl0, 0);
g1 = [g1(14:16); g1(1:6)]; % Compact filter notation
% 
%% Exercise 6.10b.
% 
omega = linspace(0,2*pi,100);
plot(omega, g1(5) + g1(6)*2*cos(omega) + g1(7)*2*cos(2*omega)...
+ g1(8)*2*cos(3*omega) + g1(9)*2*cos(4*omega))
% 
% 
% 
%% Exercise 7.1
% 
plotwaveletfunctions(@IDWTKernelHaar, -2, 6)
plotwaveletfunctions(@IDWTKernelpwl0, -2, 6)
plotwaveletfunctions(@IDWTKernelpwl2, -2, 6)
% 
%% Exercise 7.2
% 
m = 10;
t = linspace(-2, 6, 8*2^m);
coordsvm=2^(m/2)*IDWTImpl([-coeffs(1); -coeffs(2); -coeffs(4); 0;...
0; 0; 0; -coeffs(3); 1; 0; 0; 0; 0; 0;...
0; 0; zeros(8*2^m-16, 1)], ...
m, @IDWTKernelpwl0, 0);
plot(t, coordsvm([(6*2^m+1):(8*2^m) 1:(6*2^m)]))
% 
% 
% 
%% Exercise 8.9e.
% 
playDWT(m, @DWTKernel53, @IDWTKernel53, 1);
playDWT(m, @DWTKernel97, @IDWTKernel97, 1);
% 
%% Exercise 8.9f.
% 
plotwaveletfunctions(@IDWTKernel53, -4, 4)
plotwaveletfunctions(@IDWTKernel97, -4, 4)
% 
%% Exercise 8.10c.
% 
liftingfactortho(2);
playDWT(m, @DWTKernelOrtho, @IDWTKernelOrtho, 1);
liftingfactortho(3);
playDWT(m, @DWTKernelOrtho, @IDWTKernelOrtho, 1);
liftingfactortho(4);
playDWT(m, @DWTKernelOrtho, @IDWTKernelOrtho, 1);
% 
%% Exercise 8.10d.
% 
liftingfactortho(2)
plotwaveletfunctions(@IDWTKernelOrtho, -4, 4)
liftingfactortho(3)
plotwaveletfunctions(@IDWTKernelOrtho, -4, 4)
liftingfactortho(4)
plotwaveletfunctions(@IDWTKernelOrtho, -4, 4)
% 
% 
% 
%% Exercise 8.12b)
% 
H0 = [-5 20 -1 -96 70 280 70 -96 -1 20 -5]/128;
H1 = [1 -4 6 -4 1]/16;
G0 = [1 4 6 4 1]/16;
G1 = [5 20 1 -96 -70 280 -70 -96 1 20 5]/128;
f    = @(x, symm, dual) DWTKernelFilters(H0,H1,G0,G1,x,symm,dual);
invf = @(x, symm, dual) IDWTKernelFilters(H0,H1,G0,G1,x,symm,dual);
% 
%% Exercise 8.12c)
% 
playDWT(m, f, invf, 1)
% 
%% Exercise 8.12d)
% 
plotwaveletfunctions(invf, -4, 4)
% 
% 
% 
% 
% 
% 
%% Exercise 8.13
% 
x = (1:8192)';
x = mp3reversefbt(mp3forwardfbt(x));
plot(x)

