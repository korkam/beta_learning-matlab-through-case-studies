%% Linear algebra, signal processing, and wavelets. A unified approach. Matlab notebooks
% 
% Author: Øyvind Ryan
% 
% Date: Feb 17, 2016
% 
%%
antsec = 3;
fs = 44100;
f = 440;
% 
%% Creating the samples of a pure tone
% 
t = linspace(0, antsec, fs*antsec);
x = sin(2*pi*f*t);
% 
%% Listening to the pure tone and writing the samples to file
% 
playerobj = audioplayer(x, fs);
playblocking(playerobj);
audiowrite('puretone440.wav', x, fs);
% 
%% Listening to the square wave
% 
samplesperperiod=round(fs/f);
oneperiod = [ones(1,round(samplesperperiod/2)) ...
-ones(1,round(samplesperperiod/2))];
x=repmat(oneperiod,1,antsec*f);
playerobj=audioplayer(x, fs);
playblocking(playerobj);
% 
%% Listening to the triangle wave
% 
oneperiod=[linspace(-1,1,round(samplesperperiod/2)) ...
linspace(1,-1,round(samplesperperiod/2))];
x = zeros(1, antsec*f*length(oneperiod));
x=repmat(oneperiod,1,antsec*f);
playerobj=audioplayer(x, fs);
playblocking(playerobj);
% 
%% Reading from file
% 
[x, fs] = audioread('sounds/castanets.wav');
% 
% 
%% Listen to sound from the second channel
% 
playerobj=audioplayer(x(:, 2), fs);
playblocking(playerobj);
% 
% 
%% Listen to the sample audio file at normal, double, and half sample rate
% 
playerobj = audioplayer(x, fs);
playblocking(playerobj);
playerobj = audioplayer(x, 2*fs);
playblocking(playerobj);
playerobj = audioplayer(x, fs/2);
playblocking(playerobj);
% 
%% Play the sound backwards
% 
N = size(x, 1);
z = x(N:(-1):1, :);
playerobj = audioplayer(z, fs);
playblocking(playerobj);
% 
%% Adding noise
% 
c = 0.1;
z = x + c*(2*rand(size(x))-1);
z = z/max(abs(z));
playerobj = audioplayer(z, fs);
playblocking(playerobj);
% 
% 
% 
%% Exercise 2.1
% 
t1 = 0:(1/fs):(4/440);
t2 = (4/440):(1/fs):(12/440);
t3 = (12/440):(1/fs):(20/440);
f1 = 0*t1;                               % The first part of f
f2 = 2*((440*t2-4)/8).*sin(2*pi*440*t2); % The second part of f
f3 = 2*sin(2*pi*440*t3);                 % The third part of f
x = [f1 f2 f3];
x = x/max(abs(x));
playerobj=audioplayer(x, fs);
playblocking(playerobj);
% 
%% Exercise 2.2
% 
t = 0:(1/fs):3;
x = sin(2*pi*440*t) + 0.3*sin(2*pi*4400*t);
x = x/max(abs(x));
playerobj = audioplayer(x, fs);
playblocking(playerobj);
% 
%% Exercise 2.3 
% 
play_pure_sound(440)
play_pure_sound(1500)
% 
%% Exercise 2.4 
% 
play_square(1/440.0)
play_triangle(1/440.0)
% 
%% Exercise 2.5
% 
play_square_fourier(1/440.0, 9)
play_triangle_fourier(1/440.0, 9)
% 
%% Exercise 2.6 
% 
[x, fs] = audioread('sounds/castanets.wav');
play_with_different_fs(x, fs)
% 
%% Exercise 2.7 
% 
play_reverse(x, fs)
% 
%% Exercise 2.8
% 
play_with_noise( x, fs, 0.1)
% 
%% Example 2.27
% 
% The main code in |playDFT()|:
% 
L = 10000;
N = size(x, 1);
y = fft(x);
y((L+2):(N-L), :) = 0;
newx = ifft(y);
playerobj=audioplayer(newx, fs);
playblocking(playerobj);
% 
playDFT(7, 1)
playDFT(3, 1)
playDFT(7, 0)
playDFT(3, 0)
% 
%% Example 2.28
% 
% The main code in |playDFTthreshold()|:
% 
threshold = 50;
y = fft(x);
y = (abs(y) >= threshold).*y;
newx = ifft(y);
% 
playDFTthreshold(0.02);
playDFTthreshold(0.1);
% 
%% Example 2.29
% 
n = 5;
y = fft(x);
y = y/2^n;
y = round(y);
y = y*2^n;
newx = ifft(y);
playerobj=audioplayer(newx, fs);
playblocking(playerobj);
% 
%% Exercise 2.19
% 
[x, fs] = audioread('sounds/castanets.wav');
N = size(x, 1);
y = fft(x);
y((round(N/4)+1):(round(N/4)+N/2), :) = 0;
newx = abs(ifft(y));
newx = newx/max(max(newx));
playerobj = audioplayer(newx,fs);
playblocking(playerobj)
% 
% 
% 
% 
% 
%% Exercise 2.23
% 
[x0, fs] = audioread('sounds/castanets.wav');
kvals = 3:15;
slowtime=zeros(1,length(kvals));
fasttime = slowtime; fastesttime = slowtime;
N = 2.^kvals;
for k = kvals
x = x0(1:2^k,1);
tic;
y = DFTImpl(x);
slowtime(k-2) = toc;
tic;
y = FFTImpl(x, @FFTKernelStandard);
fasttime(k-2) = toc;
tic;
y = fft(x);
fastesttime(k-2) = toc;
end
% a.
plot(kvals, slowtime, 'r', ...
kvals, fasttime, 'g', ...
kvals, fastesttime, 'b')
grid on
title('time usage of the DFT methods')
legend('DFT', 'Standard FFT', 'Built-in FFT')
xlabel('log_2 N')
ylabel('time used [s]')
% b.
figure(2)
loglog(N, slowtime, 'r', N, fasttime, 'g', N, fastesttime, 'b')
axis equal
legend('DFT', 'Standard FFT', 'Built-in FFT')
% 
%% Exercise 2.28
% 
[x0, fs] = audioread('sounds/castanets.wav');
kvals = 3:15;
slowtime = zeros(1,length(kvals));
fasttime = slowtime; fastesttime = slowtime;
N = 2.^(kvals);
for k = kvals
x = x0(1:2^k,1);
tic;
y = FFTImpl(x, @FFTKernelStandard);
slowtime(k-2) = toc;
tic;
y = FFTImpl(x, @FFTKernelNonrec);
fasttime(k-2) = toc;
tic;
y = FFTImpl(x, @FFTKernelSplitradix);
fastesttime(k-2) = toc;
end
plot(kvals, slowtime, 'ro-')
hold on 
plot(kvals,fasttime, 'bo-')
plot(kvals,fastesttime, 'go-')
grid on
title('time usage of the DFT methods')
legend('Standard FFT algorithm', ...
'Non-recursive FFT', ...
'Split radix FFT')
xlabel('log_2 N')
ylabel('time used [s]')
% 
% 
%% Exercise 3.23
% 
[x, fs] = audioread('sounds/castanets.wav');
play_with_echo(x, fs, 0.5, 20000);
% 
%% Exercise 3.25
% 
play_with_reduced_treble(x, fs, 32); 
play_with_reduced_bass(x, fs, 2);
% 
% 
% 
% 

