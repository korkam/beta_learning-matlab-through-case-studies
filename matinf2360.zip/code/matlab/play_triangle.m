function play_triangle(T)
    % Play a triangle wave with period T over 3 seconds
    fs = 44100;
    numsec = 3;
    samplesperperiod = round(fs*T);
    oneperiod=[linspace(-1, 1, round(samplesperperiod/2)) ...
             linspace(1, -1, round(samplesperperiod/2))];
    numperiods = floor(numsec/T);
    x = repmat(oneperiod, 1, numperiods);
    playerobj=audioplayer(x, fs);
    playblocking(playerobj)
 