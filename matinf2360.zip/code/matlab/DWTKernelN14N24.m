function x = DWTKernelN14N24(x, symm, dual)
    N = size(x, 1);
    if dual
        x = liftingstepoddsymm(1/4, x, symm);
        x = liftingstepevensymm(1, x, symm);
        x = liftingstepodd2symm(-29/128, 5/128, x,symm);
        x(1:2:N, :) = x(1:2:N, :)/4;
        x(2:2:N, :) = x(2:2:N, :)*4;
    else
        x = liftingstepevensymm(-1/4, x, symm);
        x = liftingstepoddsymm(-1, x, symm);
        x = liftingstepeven2symm(29/128, -5/128, x, symm);
        x(1:2:N, :) = x(1:2:N, :)*4;
        x(2:2:N, :) = x(2:2:N, :)/4;
    end