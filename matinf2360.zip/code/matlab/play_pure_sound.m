function play_pure_sound(f)
  fs=2.5*f;
  t=0:(1/fs):3;
  x=sin(2*pi*f*t);
  playerobj=audioplayer(x,fs);
  playblocking(playerobj)