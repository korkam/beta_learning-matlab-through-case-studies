function play_square_fourier(T,N)
  fs=44100;
  t=0:(1/fs):3;
  x=zeros(1,length(t));
  n=1;
  while n<=N
    x = x + (4/(n*pi))*sin(2*pi*n*t/T);
    n=n+2;
  end
  x=x/max(abs(x));
  playerobj=audioplayer(x,fs);
  playblocking(playerobj)