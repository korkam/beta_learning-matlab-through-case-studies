function x = IDWTKernelOrtho(x, symm, dual)
    global lambdas alpha beta
    N = size(x, 1);
  
    if dual
        stepnr = 1;
        if mod(size(lambdas, 1), 2) == 1
            x = liftingstepodd(-lambdas(stepnr, 2), -lambdas(stepnr, 1), x);
            stepnr = stepnr + 1;
        end
  
        while stepnr < size(lambdas, 1)
            x = liftingstepeven(-lambdas(stepnr, 2), -lambdas(stepnr, 1), x);
            stepnr = stepnr + 1;
            x = liftingstepodd(-lambdas(stepnr, 2), -lambdas(stepnr, 1), x);
            stepnr = stepnr + 1;
        end
 
        x(1:2:N, :) = x(1:2:N, :)*alpha;
        x(2:2:N, :) = x(2:2:N, :)*beta;
    else
        stepnr = 1;
        if mod(size(lambdas, 1), 2) == 1
            x = liftingstepeven(lambdas(stepnr, 1), lambdas(stepnr, 2), x);
            stepnr = stepnr + 1;
        end
  
        while stepnr < size(lambdas, 1)
            x = liftingstepodd(lambdas(stepnr, 1), lambdas(stepnr, 2), x);
            stepnr = stepnr + 1;
            x = liftingstepeven(lambdas(stepnr, 1), lambdas(stepnr, 2), x);
            stepnr = stepnr + 1;
        end
 
        x(1:2:N, :)=x(1:2:N, :)/alpha;
        x(2:2:N, :)=x(2:2:N, :)/beta;
    end