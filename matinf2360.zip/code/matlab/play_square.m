function play_square(T)
    % Play a square wave with period T over 3 seconds
    fs = 44100;
    numsec = 3;
    samplesperperiod = round(fs*T);
    oneperiod=[ones(1, round(samplesperperiod/2)) ...
               -ones(1, round(samplesperperiod/2))];
    numperiods = floor(numsec/T);
    x=repmat(oneperiod, 1, numperiods);
    playerobj=audioplayer(x, fs);
    playblocking(playerobj)
  