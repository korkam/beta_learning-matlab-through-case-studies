function play_with_noise(x, fs, c)
    z = x + c*(2*rand(size(x)) - 1);
    z = z/max(max(abs(z)));
    playerobj=audioplayer(z, fs);
    playblocking(playerobj);