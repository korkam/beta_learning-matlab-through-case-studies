function play_with_reduced_treble(x,fs,k)
    t = [1];
    for kval=1:k
        t = conv(t,[1/2 1/2]);
    end
    z = conv(t, x(:, 1));
    playerobj=audioplayer(z,fs);
    playblocking(playerobj);