function play_reverse(x,fs)
  N = size(x,1);
  playerobj=audioplayer(x(N:(-1):1, :), fs);
  playblocking(playerobj);