function x = IDWTKernelN14N24(x, symm, dual)
    N = size(x, 1);
    if dual
        x(1:2:N, :) = x(1:2:N, :)*4;
        x(2:2:N, :) = x(2:2:N, :)/4;
        x = liftingstepodd2symm(29/128, -5/128, x, symm);
        x = liftingstepevensymm(-1, x, symm);
        x = liftingstepoddsymm(-1/4, x, symm);
    else
        x(1:2:N, :)=x(1:2:N, :)/4;
        x(2:2:N, :)=x(2:2:N, :)*4;
        x = liftingstepeven2symm(-29/128, 5/128, x, symm);
        x = liftingstepoddsymm(1, x, symm);
        x = liftingstepevensymm(1/4, x, symm);
    end