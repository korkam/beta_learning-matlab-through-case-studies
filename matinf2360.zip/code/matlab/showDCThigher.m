function showDCThigher(threshold)
    img = double(imread('images/lena.png', 'png'));
    zeroedout = 0;
    img = tensor_impl(img, @DCTImpl8, @DCTImpl8);
    thresholdmatr = (abs(img) >= threshold);
    zeroedout = zeroedout + prod(size(img)) ...
                - sum(sum(sum(thresholdmatr)));
    img = tensor_impl(img.*thresholdmatr, @IDCTImpl8, @IDCTImpl8);
    imshow(uint8(255*mapto01(img)));
    fprintf('%i percent of samples zeroed out\n', ...
        100*zeroedout/prod(size(img)));
    
function x = DCTImpl8(x)
    N = size(x, 1);
    for n = 1:8:N
        x(n:(n+7), :) = DCTImpl(x(n:(n+7), :));
    end
    
function x = IDCTImpl8(x)
    N = size(x, 1);
    for n = 1:8:N
        x(n:(n+7), :) = IDCTImpl(x(n:(n+7), :));
    end