function play_with_echo(x,fs,c,d)
  [N,nchannels] = size(x);
  z = zeros(N,nchannels);
  z(1:d,:) = x(1:d,:);
  z((d+1):N,:) = x((d+1):N,:)+c*x(1:(N-d),:); % Add echo
  z = z/max(max(abs(z))); % Scale so that sound values are within [-1,1].
  playerobj=audioplayer(z,fs);
  playblocking(playerobj);