function plotwaveletfunctions(invf,a,b)
    % Plot scaling functions and mother wavelets (dual or not),...
    %  using the cascade algorithm.
    nres = 10;
    t=linspace(a,b,(b-a)*2^nres);

    coordsvm = zeros((b-a)*2^nres, 1);
    coordsvm(1) = 1;
    coordsvm = 2^(nres/2)*IDWTImpl(coordsvm, nres, invf, 0, 0);
    subplot(2, 2, 1);
    plot(t,coordsvm([(b*2^nres+1):((b-a)*2^nres) 1:(b*2^nres)]))
    title('\phi')

    coordsvm = zeros((b-a)*2^nres, 1);
    coordsvm(b - a + 1) = 1;
    coordsvm = 2^(nres/2)*IDWTImpl(coordsvm, nres, invf, 0, 0);
    subplot(2, 2, 2);
    plot(t,coordsvm([(b*2^nres+1):((b-a)*2^nres) 1:(b*2^nres)])) 
    title('\psi')

    coordsvm = zeros((b-a)*2^nres, 1);
    coordsvm(1) = 1;
    coordsvm = 2^(nres/2)*IDWTImpl(coordsvm, nres, invf, 0, 1);
    subplot(2, 2, 3);
    plot(t,coordsvm([(b*2^nres+1):((b-a)*2^nres) 1:(b*2^nres)])) 
    title('\phi~')

    coordsvm = zeros((b-a)*2^nres, 1);
    coordsvm(b - a + 1) = 1;
    coordsvm = 2^(nres/2)*IDWTImpl(coordsvm, nres, invf, 0, 1);
    subplot(2, 2, 4);
    plot(t,coordsvm([(b*2^nres+1):((b-a)*2^nres) 1:(b*2^nres)])) 
    title('\psi~')