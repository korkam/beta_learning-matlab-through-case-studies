function x = IDWTKernelpwl4(x, symm, dual)
    alpha = 0.296875000000000;
    gamma = -0.046875000000000;
    if dual
        x = x*sqrt(2);
        x = liftingstepodd2symm(alpha, gamma, x, symm);
        x = liftingstepevensymm(-0.5, x, symm);
    else
        x = x/sqrt(2);
        x = liftingstepeven2symm(-alpha, -gamma, x, symm);
        x = liftingstepoddsymm(0.5, x, symm);
    end