function play_with_different_fs(x,fs)
  playerobj=audioplayer(x,fs);
  playblocking(playerobj);
  playerobj=audioplayer(x,2*fs);
  playblocking(playerobj);
  playerobj=audioplayer(x,fs/2);
  playblocking(playerobj);