function x = DWTKernelOrtho(x, symm, dual)
    global lambdas alpha beta
    N = size(x, 1);
  
    if dual
        x(1:2:N, :) = x(1:2:N, :)/alpha;
        x(2:2:N, :)=x(2:2:N, :)/beta;
        for stepnr = size(lambdas,1):(-2):2
            x = liftingstepodd(lambdas(stepnr,2), lambdas(stepnr,1), x);
            x = liftingstepeven(lambdas(stepnr-1,2), lambdas(stepnr-1,1), x);
        end
  
        if stepnr == 3
            x = liftingstepodd(lambdas(1,2), lambdas(1,1), x);
        end
    else
        x(1:2:N, :) = x(1:2:N, :)*alpha;
        x(2:2:N, :) = x(2:2:N, :)*beta;
        for stepnr = size(lambdas,1):(-2):2
            x = liftingstepeven(-lambdas(stepnr,1), -lambdas(stepnr,2), x);
            x = liftingstepodd(-lambdas(stepnr-1,1), -lambdas(stepnr-1,2), x);
        end
  
        if stepnr == 3
            x = liftingstepeven(-lambdas(1,1), -lambdas(1,2), x);
        end
    end