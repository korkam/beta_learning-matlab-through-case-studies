import math, wave, commands, sys, os
from numpy import *

max_amplitude = 2**15-1 # iinfo('int16').max if numpy >= 1.0.3

def filterS(t, x, symm):
    tlen = len(t) 
    N0 = (tlen - 1)/2
    N = shape(x)[0]
    
    if symm:
        y = concatenate([ x[N0:0:(-1)], x, x[(N-2):(N - N0 - 2):(-1)] ])
    else:
        y = concatenate([ x[(N - N0):], x, x[:N0]])
    if ndim(x) == 1:
        res = convolve(t, y)
        x[:] = res[(2*N0):(len(res)-2*N0)]
    else:
        n = shape(x)[1]
        for k in range(n):
            res = convolve(t, y[:, k])
            x[:, k] = res[(2*N0):(len(res)-2*N0)]
            
            
def audiowrite(filename, x, fs):
    """
    Writes the array data to the specified filename.
    The array data type can be arbitrary as it will be
    converted to numpy.int16 in this function.
    """
    ofile = wave.open(filename, 'w')
    ofile.setsampwidth(2)
    ofile.setframerate(fs)
    if x.ndim == 1:
        ofile.setnchannels(1)
    else:
        m, n = shape(x)
        ofile.setnchannels(n)
        x=x.flatten()
    x=max_amplitude*x
    x=x.astype(int16)
    x=x.astype(uint16)
    ofile.writeframesraw(x.astype(uint16).tostring())
    ofile.close()

def audioread(filename):
    """
    Read sound data in a file and return the data as an array
    with data type numpy.float, together with the sampling rate.
    Each sound channel will be a column in the array.
    """
    ifile = wave.open(filename)
    channels = ifile.getnchannels()
    fs = ifile.getframerate()
    frames = ifile.getnframes()
    x = ifile.readframes(frames)
    x = fromstring(x, dtype=uint16) 
    x=x.astype(int16)
    x=x.astype(float)/max_amplitude
    soundx = x
    if channels > 1:
        soundx = x.reshape((len(x)/channels,channels))
    return soundx,fs

def play(x, fs, player=None):
    """
    Play a file with array data.  (The array is first written to file
    using the audiowrite function so the data type can be arbitrary.)  The
    player is chosen by the programs 'open' on Mac and 'start' on
    Windows. On Linux, try different open programs for various
    distributions. If keyword argument `player` is given, only this
    spesific command is run.
    """
    tmpfile = 'tmp.wav'
    audiowrite(tmpfile, x, fs)

    if player:
        msg = 'Unable to open sound file with %s' %player
        if sys.platform[:3] == 'win':
            status = os.system('%s %s' %(player, tmpfile))
        else:
            status, output = commands.getstatusoutput('%s %s' %(player, tmpfile))
            msg += '\nError message:\n%s' %output
        if status != 0:
            raise OSError(msg)
        return

    if sys.platform[:5] == 'linux':
        open_commands = ['gnome-open', 'kmfclient exec', 'exo-open', 'xdg-open', 'open']
        for cmd in open_commands:
            status, output = commands.getstatusoutput('%s %s' %(cmd, tmpfile))
            if status == 0:
                break
        if status != 0:
            raise OSError('Unable to open sound file, try to set player'\
                              ' keyword argument.')

    elif sys.platform == 'darwin':
        commands.getstatusoutput('open %s' %tmpfile)
    else:
        # assume windows
        os.system('start %s' %tmpfile)

def play_with_different_fs( x, fs):
    play(x, fs)
    raw_input('PRESS ENTER TO CONTINUE.')
    play(x, 2*fs)
    raw_input('PRESS ENTER TO CONTINUE.')
    play(x, fs/2)
  
def play_reverse(x, fs):
    """
    Play the sound backwards.
    """
    N = shape(x)[0]
    play(x[(N-1)::(-1)], fs)

def play_with_noise(x, fs, c=0.1):
    """
    Play the sound with noise added. c represents the noise level,
    a number between 0 and 1.
    """
    z = x + c*(2*random.random(shape(x))-1)
    z /= abs(z).max()
    play(z, fs)

def play_with_echo(x, fs, c, d):
    """
    Play the sound with an echo added. 
    
    x: the vector of sound samples
    fs: the sample rate
    c:the strength of the echo
    d: the delay of the echo in samples.
    """
    N,nchannels = shape(x)
    z = zeros((N,nchannels))
    z[0:d] = x[0:d]
    z[d:N] = x[d:N] + c*x[0:(N-d)]
    z /= abs(z).max()
    play(z, fs)
    

def play_with_reduced_treble( x, fs, k):
    t = [1.]
    for kval in range(k):
        t = convolve(t, [1/2., 1/2.])
    N,nchannels=shape(x)
    z = convolve(t, x[:, 0])
    play(z,fs)
    
def play_with_reduced_bass( x, fs, k):
    t = [1.]
    for kval in range(k):
        t = convolve(t, [1/2., -1/2.])
    N,nchannels=shape(x)
    z = convolve(t, x[:, 0])
    play(z,fs)
  
def play_pure_sound(f):
    """
    Play a pure sound with a given frequency over three seconds.
    """
    fs = 44100
    t = linspace(0, 3, 3*fs)
    x = sin(2*pi*f*t)
    play(x, fs)
  
def play_square(T):
    length=3
    fs = 44100
    samplesperperiod = fs*T
    oneperiod = hstack([ones((samplesperperiod/2),dtype=float),\
                         -ones((samplesperperiod/2),dtype=float)])
    x = tile(oneperiod,length/T)
    play(x, fs)

def play_square_fourier(T, N):
    length = 3
    fs = 44100
    t = linspace(0, length, fs*length)
    x = zeros(t.size)
    for n in range(1,N+1,2):
        x += sin(2*pi*n*t/T)/n
    x *= 4/pi
    x /= abs(x).max()
    play(x, fs)

def play_triangle(T):
    length = 3
    fs = 44100
    samplesperperiod = fs*T
    oneperiod = hstack([linspace(-1, 1, samplesperperiod/2), \
                        linspace(1, -1, samplesperperiod/2)])
    x = tile(oneperiod, length/T)
    play(x, fs)

def play_triangle_fourier(T, N):
    length = 3
    fs = 44100
    t = linspace(0, length, fs*length)
    x = zeros(t.size)
    for n in range(1,N+1,2):
        x -= cos(2*pi*n*t/T)/n**2
    x *= 8/(pi**2)
    x /= abs(x).max()
    play(x,fs)