from scipy.fftpack import dct
from fft import *

def _testdct():
    x1 = random.random(32)
    x2 = random.random((32,3))
    x2copy = zeros_like(x2); x2copy[:] = x2[:]
    
    print 'Testing DCTImpl'
    x = dct(x1, norm='ortho', axis=0)
    x1copy = x1.copy()
    DCTImpl(x1copy) 
    diff = abs(x1copy-x).max()
    assert diff < 1E-13, 'bug, diff=%s' % diff
    
    x = dct(x2, norm='ortho', axis=0)
    x2copy = x2.copy()
    DCTImpl(x2copy) 
    diff = abs(x2copy-x).max()
    assert diff < 1E-13, 'bug, diff=%s' % diff
    
    
    print 'Testing that IDCTImpl inverts DCTImpl'
    x1copy = x1.copy()
    DCTImpl(x1copy) 
    IDCTImpl(x1copy) 
    diff = abs(x1copy-x1).max()
    assert diff < 1E-13, 'bug, diff=%s' % diff
    
    x2copy = x2.copy()
    DCTImpl(x2copy) 
    IDCTImpl(x2copy) 
    diff = abs(x2copy-x2).max()
    assert diff < 1E-13, 'bug, diff=%s' % diff
    
if __name__=='__main__':
    _testdct()