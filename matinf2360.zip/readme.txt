All code assumes that the directory where this file resides is used as working directory: Paths to images and sounds are resolved based on this assumption. 

If you plan to use Matlab you should add "code/matlab/" to your matlab path. 
If you are administrator on the PC, you can do this using the "Set Path"-button in Matlab. 
If you are not administrator on the PC, you must write "userpath(path)" in Matlab, where path is the absolute path to "code/matlab/". 
This must then be done everytime you start Matlab.


If you plan to use Python you should add "code/python/" to your path. The ipython notebooks add this to the path directly in the code.

The python code requires numpy and matplotlib. To run the ipython notebooks, jupyter is also required. 
On Mac OSX and Windows we recommend you use anaconda. 
A conda environment (with name equal to name of the course) can be created and activated, 
and all these packages installed with the following lines.

conda create --name matinf2360 python
conda install --name matinf2360 matplotlib
conda install --name matinf2360 scipy
source activate matinf2360
pip install jupyter
pip install jupyter --upgrade






On windows we also recommend using anaconda. The recipe for creating the needed conda environment is the same, but you need to replace 
"source activate matinf2360" with "activate matinf2360" in the code above.

Known issues: 
1. If you get an error message of the type "unknown locale UTF-8": See the bottom of page 827 in the fourth edition of the INF1100 textbook, where there is a fix for this. 
2. You may also need to install ipython (conda install --name matinf2360 ipython).

Ubuntu: The same python packages as above are needed, install them with apt-get or pip.