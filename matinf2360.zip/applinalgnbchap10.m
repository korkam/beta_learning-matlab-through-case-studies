%% Linear algebra, signal processing, and wavelets. A unified approach. Matlab notebooks
% 
% Author: Øyvind Ryan
% 
% Date: Feb 17, 2016
% 
%%
m = 2;
% 
%% Example 10.17
% 
showDWT(m, @DWTKernelHaar, @IDWTKernelHaar, 1);
showDWT(m, @DWTKernel53, @IDWTKernel53, 1);
showDWT(m, @DWTKernel97, @IDWTKernel97, 1);
% 
%% Exercise 10.4e.
% 
showDWT(m, @DWTKernelHaar, @IDWTKernelHaar, 0);
showDWT(m, @DWTKernel53, @IDWTKernel53, 0);
showDWT(m, @DWTKernel97, @IDWTKernel97, 0);
% 
%% Lowres components for other wavelets
% 
showDWT( m, @DWTKernelpwl0, @IDWTKernelpwl0, 1)
showDWT( m, @DWTKernelpwl2, @IDWTKernelpwl2, 1)
% 
%% Detail components for other wavelets
% 
showDWT( m, @DWTKernelpwl0, @IDWTKernelpwl0, 0)
showDWT( m, @DWTKernelpwl2, @IDWTKernelpwl2, 0)

