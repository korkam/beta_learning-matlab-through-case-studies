a = [1,2,3;2,6,4;1,2,round(rand(1)*5)];
a = a';
a = inv(a);
