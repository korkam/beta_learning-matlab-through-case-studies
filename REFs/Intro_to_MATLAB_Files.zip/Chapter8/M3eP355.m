% M3eP355.m
% Script file lineq.m
% Solves the set Ax = b, given A and b.
% Check the ranks of A and [A b].
if rank(A) == rank([A b])
% The ranks are equal.
size_A = size(A);
% Does the rank of A equal the number of unknowns?
if rank(A) == size_A(2)
% Yes. Rank of A equals the number of unknowns.
disp('There is a unique solution, which is:')
x = A\b % Solve using left division.
else
% Rank of A does not equal the number of unknowns.
disp('There is an infinite number of solutions.')
disp('The augmented matrix of the reduced system is:')
rref([A b]) % Compute the augmented matrix.
end
else
% The ranks of A and [A b] are not equal.
disp('There are no solutions.')
end