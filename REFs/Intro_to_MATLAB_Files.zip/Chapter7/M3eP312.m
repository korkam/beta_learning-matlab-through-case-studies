% M3eP312.m
s = 0.05; % standard deviation of x and y
n = 8000; % number of random simulations
x = 10 + s*randn(1,n);
y = 3.64 + s*randn(1,n);
theta = (180/pi)*atan(y./x);
mean_theta = mean(theta)
sigma_theta = std(theta)
xp = 19:0.1:21;
z = hist(theta,xp);
yp = z/n;
bar(xp,yp),xlabel('Theta (degrees)'),...
ylabel('Relative Frequency')