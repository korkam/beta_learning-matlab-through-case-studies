% M3eP399A.m
% Relative frequency histogram using the bar function.
tests = 100;
y = [13,15,22,19,17,14]/tests;
x = 91:96;
bar(x,y),ylabel('Relative Frequency'),...
xlabel('Thread Strength (N)'),...
title('Relative Frequency Histogram for 100 Tests')