% M3eP306.m
mu = 69.3;
s = 1.96;
% How many are no taller than 68 inches?
b1 = 68;
P1 = (1+erf((b1-mu)/(s*sqrt(2))))/2
% How many are within 3 inches of the mean?
a2 = 66.3;
b2 = 72.3;
P2 = (erf((b2-mu)/(s*sqrt(2)))-erf((a2-mu)/(s*sqrt(2))))/2