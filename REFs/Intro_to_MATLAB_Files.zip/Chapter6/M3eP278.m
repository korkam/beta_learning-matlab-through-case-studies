% M3eP278.m
% Time data
x = 0:19;
% Population data
y = [6,13,23,33,54,83,118,156,210,282,...
350,440,557,685,815,990,1170,1350,1575,1830];
% Linear fit
p1 = polyfit(x,y,1);
% Quadratic fit
p2 = polyfit(x,y,2);
% Cubic fit
p3 = polyfit(x,y,3);
% Exponential fit
p4 = polyfit(x,log10(y),1);
% Residuals
res1 = polyval(p1,x)-y;
res2 = polyval(p2,x)-y;
res3 = polyval(p3,x)-y;
res4 = 10.^polyval(p4,x)-y;
subplot(2,2,1)
plot(x,res1,'o',x,res1)
subplot(2,2,2)
plot(x,res2,'o',x,res2)
subplot(2,2,3)
plot(x,res3,'o',x,res3)
subplot(2,2,4)
plot(x,res4,'o',x,res4)
