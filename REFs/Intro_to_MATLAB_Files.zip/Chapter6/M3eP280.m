% M3eP280.m
x1 = (0:3)';x2 = [5,7,8,11]';
y = [7.1,19.2,31,45]';
X = [ones(size(x1)), x1, x2];
a = X\y
yp = X*a;
Max_Percent_Error = 100*max(abs((yp-y)./y))