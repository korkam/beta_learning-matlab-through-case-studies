% M3eP270.m
% Data for the problem.
cups = [6,9,12,15];
meas_times = [9,8,7,6];
meas_flow = 1./meas_times;
%
% Fit a straight line to the transformed data.
p = polyfit(log10(cups),log10(meas_flow),1);
coeffs = [p(1),10^p(2)];
m = coeffs(1)
b = coeffs(2)
%
% Plot the data and the fitted line on a loglog plot to see
% how well the line fits the data.
x = 6:0.01:40;
y = b*x.^m;
subplot(2,1,1)
loglog(x,y,cups,meas_flow,'o'),grid,xlabel('Volume (cups)'), ...
ylabel('Flow Rate (cups/sec)'),axis([5 15 0.1 0.3])
%Plot the fill time curve extrapolated to 36 cups.
subplot(2,1,2)
plot(x,1./y,cups,meas_times,'o'),grid,xlabel('Volume(cups)'),...
ylabel('Fill Time per Cup (sec)'),axis([5 36 0 10])
%
% Compute the fill time for V = 36 cups.
fill_time = 1/(b*36^m)