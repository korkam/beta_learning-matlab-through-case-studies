% M3eP239.m
% Program on page 239.

%% Example of Report Publishing:
% Plotting the cubic y = x^3 - 6x^2 + 10x+4.
%% Create the independent variable.
x = linspace(0, 4, 300); % Use 300 points between 0 and 4.
%% Define the cubic from its coefficients.
p = [1, -6, 10, 4]; % p contains the coefficients.
%% Plot the cubic
plot(x, polyval(p, x)), xlabel('x'), ylabel('y')