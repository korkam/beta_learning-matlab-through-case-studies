% M3eP231
% Program on page 231.
x = -1:0.01:1;
y1 = 3+exp(-x).*sin(6*x);
y2 = 4+exp(-x).*cos(6*x);
plot((0.1+0.9i).^(0:0.01:10)),hold,plot(y1,y2),...
    gtext('y2 versus y1'),gtext('Imag(z) versus Real(z)')