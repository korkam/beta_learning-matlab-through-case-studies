% M3eP238.m
% Program on page 238.
% errorbar example
x = linspace(0.1, pi, 20);
approx = 1 - x.^2/2;
error = approx - cos(x);
errorbar(x, cos(x), error), legend('cos(x)'), ...
    title('Approximation = 1 - x^2/2')