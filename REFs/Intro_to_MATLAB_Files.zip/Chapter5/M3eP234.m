% M3eP234.m
% Program on page 234.
% Create the Rectilinear Plot
x1 = 0:0.01:100; u1 = x1.^2;
num1 = 100*(1-0.01*u1).^2 + 0.02*u1;
den1 = (1-u1).^2 + 0.1*u1;
y1 = sqrt(num1./den1);
subplot(1,2,1), plot(x1,y1),xlabel('x'),ylabel('y'),
% Create the Loglog Plot
x2 = logspace(-2, 2, 500); u2 = x2.^2;
num2 = 100*(1-0.01*u2).^2 + 0.02*u2;
den2 = (1-u2).^2 + 0.1*u2;
y2 = sqrt(num2./den2);
subplot(1,2,2), loglog(x2,y2),xlabel('x'),ylabel('y')