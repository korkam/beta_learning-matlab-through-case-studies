% Program M3eP81to82.m
% Combination of separate programs on pages 81-82.
U = [6, 2, 1;2, 5, 4;4, 3, 2;9, 7, 3];
P = [10, 12, 13, 15;8, 7, 6, 4;12, 10, 13, 9;6, 4, 11, 5];
C = U'*P
Quarterly_Costs = sum(C)
Category_Costs = sum(C')
