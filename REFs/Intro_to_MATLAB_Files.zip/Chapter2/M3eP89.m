% M3eP89.m
% Program on page 89.
k = 5e+6;m = 1000;
alpha = k/(4*m*pi^2);
p1 = [-1,0,alpha];
p2 = [-1,0,2*alpha];
p3 = [alpha^2,0,-2*alpha^3];
p4 = conv(p2,p2)-[0,0,0,0,alpha^2];
p5 = conv(p1,p4);
p6 = p5+[0,0,0,0,p3];
r = roots(p6)