% M3eP396.m
function xdot = msd(t,x)
% Function file for mass with spring and damping.
% Position is first variable, velocity is second variable.
u = 10;
m = 1;c = 2;k = 5;
A = [0, 1;-k/m, -c/m];
B = [0; 1/m];
xdot = A*x+B*u;