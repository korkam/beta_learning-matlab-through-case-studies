%M3eP379.m
x = 0:pi/50:pi;
n = length(x);
% Data-generation function with +/�0.025 random error.
y = sin(x)+.05*(rand(1,51)-0.5);
% Backward difference estimate of dy/dx.
d1 = diff(y)./diff(x);
subplot(2,1,1)
plot(x(2:n),d1,x(2:n),d1,'o')
% Central difference estimate of dy/dx.
d2 = (y(3:n)-y(1:n-2))./(x(3:n)-x(1:n-2));
subplot(2,1,2)
plot(x(2:n-1),d2,x(2:n-1),d2,'o')