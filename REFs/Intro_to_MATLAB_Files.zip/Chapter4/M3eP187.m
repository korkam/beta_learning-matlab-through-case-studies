% M3eP187.m
% Program on page 187.
% Script file rocket2.m
% Computes time to reach desired height.
% Set the data values.
h_desired = 40000; m_e = 100; q = 1;
u = 8000; g = 32.2; dt = 0.1; b = 50;
% Compute values at burnout, peak time, and height.
m_0 = m_e + q*b; v_b = u*log(m_0/m_e) - g*b;
h_b = ((u*m_e)/q)*log(m_e/(m_e+q*b))+u*b - 0.5*g*b^2;
t_p = b + v_b/g;
h_p = h_b + v_b^2/(2*g);
% If h_p > h_desired, compute time to reached h_desired.
if h_p > h_desired
h = 0; k = 0;
while h < h_desired % Compute h until h = h_desired.
t = k*dt; k = k + 1;
if t <= b
% Burnout has not yet occurred.
h = (u/q)*(m_0 - q*t)*log(m_0 - q*t)...
+ u*(log(m_0) + 1)*t - 0.5*g*t^2 ...
- (m_0*u/q)*log(m_0);
else
% Burnout has occurred.
h = h_b - 0.5*g*(t - b)^2 + v_b*(t - b);
end
end
% Display the results.
disp('The time to reach the desired height is:')
disp(t)
else
disp('Rocket cannot achieve the desired height.')
end