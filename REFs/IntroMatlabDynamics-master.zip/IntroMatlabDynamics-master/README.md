# Introductory Tutorial in Matlab Dynamics

This tutorial was written by Matthew Kelly and Jesse Miller for Cornell MAE2030, Spring Semester 2016.


