function rl = randomness(limit,n,m)
rl = floor(rand(n,m)*limit)+1
end