function mi = identity(n)
mi = zeros(n,n);
mi(1:n+1:end) = 1;
end