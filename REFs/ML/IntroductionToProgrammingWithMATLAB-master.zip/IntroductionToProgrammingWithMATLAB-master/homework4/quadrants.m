function Q = quadrants(n)
a = ones(n)
Q = [a a*2;a*3 a*4]
return 