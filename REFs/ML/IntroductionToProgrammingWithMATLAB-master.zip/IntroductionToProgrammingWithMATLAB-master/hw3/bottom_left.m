function bl = bottom_left(N,n)
bl = N(end-n+1:end,1:n)
end