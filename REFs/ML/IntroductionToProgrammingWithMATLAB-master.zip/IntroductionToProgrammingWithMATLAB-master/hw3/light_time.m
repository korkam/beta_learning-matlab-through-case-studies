function [m,d]=light_time(ir)
d=ir*1.609
m=ir*1.609/300000/60