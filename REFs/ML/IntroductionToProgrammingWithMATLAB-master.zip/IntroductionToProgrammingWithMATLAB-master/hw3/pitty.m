function c = pitty(ab)
ab = ab.^2
c = sqrt(ab(1:end,1)+ab(1:end,2))


