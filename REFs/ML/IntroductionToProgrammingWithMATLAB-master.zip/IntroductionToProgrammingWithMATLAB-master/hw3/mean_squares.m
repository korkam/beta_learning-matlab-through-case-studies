function mm = mean_squares(nn)
v=[1:nn].^2
mm=sum(v)/nn