function s=rich(rv)
s=(rv(1)+rv(2)*5+rv(3)*10+rv(4)*25)/100
end