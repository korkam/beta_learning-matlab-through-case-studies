function a=odd_index(m)
a=m(1:2:end,1:2:end)
end