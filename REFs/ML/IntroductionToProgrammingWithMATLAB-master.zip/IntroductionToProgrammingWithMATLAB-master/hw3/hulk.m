function H = hulk(v)
H = [v' (v.^2)' (v.^3)']
end