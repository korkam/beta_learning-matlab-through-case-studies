# Quantitative Neurobiology

Notes, assignments, and code for Quantitative Neurobiology (Spring 2017).

[jmxpearson.com/matlab-neurobio](http://jmxpearson.com/matlab-neurobio)
