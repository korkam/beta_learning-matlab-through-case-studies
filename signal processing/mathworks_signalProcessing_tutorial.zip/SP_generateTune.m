%% Script generates musical notes and then arranges them to create a
%  musical tune. The attack and delay are modeled when generating the
%  notes and the spectrum of the generated tune is plotted. Another file
%  SP_generateDoReMiTune shows how you can use array based processing and
%  add noise when synthesizing a tune.

clear all
close all

%% Define parameters
% Music parameters
beat = 1/4; % Quarter note per beat
tempo = 120; % Beats per minute
% Signal Processing Parameters 
fSampling = 4000; % Choose Sampling Frequency 
  
%% Create Time Vector for a single note
% Note duration can be obtained from beat and tempo specification.
% Specifcically, note duration = 60seconds/(tempo*beat)
noteDuration = 60/(tempo*beat); 
t = 0:1/fSampling:noteDuration;
% Find indices for length of beats
wholeNote = length(t);
halfNote = ceil(wholeNote/2);
threeQuarterNote = ceil(3*wholeNote/4);
quarterNote = ceil(wholeNote/4);
eighthNote = ceil(wholeNote/8);

%% Set Note frequencies
fnote = 2*[262 294 330 349 392 440 494];
%% Create Notes data and organize into Columns so that each column is a single note

Do = sin(2*pi*fnote(1)*t);%C
Re = sin(2*pi*fnote(2)*t);%D
Mi = sin(2*pi*fnote(3)*t);%E 
Fa = sin(2*pi*fnote(4)*t);%F
So = sin(2*pi*fnote(5)*t);%G
La = sin(2*pi*fnote(6)*t);%A
Ti = sin(2*pi*fnote(7)*t);%B
%% Create random exponential weight vectors for each note

expWtCnst = 6;
attackTime = ceil(wholeNote/200);
expWt = 1-exp(-abs(expWtCnst*t(1:attackTime)));
expWt = [expWt, exp(-abs(expWtCnst*t(attackTime+1:end)))];
Do = Do.*expWt;
Re = Re.*expWt;
Mi = Mi.*expWt;
Fa = Fa.*expWt;
So = So.*expWt;
La = La.*expWt;
Ti = Ti.*expWt;

%% Generate Tune

myTune = [ ...
    Do(1:quarterNote),Do(1:quarterNote),So(1:quarterNote),So(1:quarterNote), La(1:quarterNote),La(1:quarterNote),So(1:halfNote), ...
    Fa(1:quarterNote),Fa(1:quarterNote),Mi(1:quarterNote),Mi(1:quarterNote), Re(1:quarterNote),Re(1:quarterNote),Do(1:halfNote), ...
    So(1:quarterNote),So(1:quarterNote),Fa(1:quarterNote),Fa(1:quarterNote), Mi(1:quarterNote),Mi(1:quarterNote),Re(1:halfNote), ...
    So(1:quarterNote),So(1:quarterNote),Fa(1:quarterNote),Fa(1:quarterNote), Mi(1:quarterNote),Mi(1:quarterNote),Re(1:halfNote), ...
    Do(1:quarterNote),Do(1:quarterNote),So(1:quarterNote),So(1:quarterNote), La(1:quarterNote),La(1:quarterNote),So(1:halfNote), ...
    Fa(1:quarterNote),Fa(1:quarterNote),Mi(1:quarterNote),Mi(1:quarterNote), Re(1:quarterNote),Re(1:quarterNote),Do(1:halfNote), ...
    ];

%% Listen to the tune
soundsc(myTune,fSampling)

%% Save files
save('twinkleTune.mat','myTune','fSampling');
wavwrite(myTune,fSampling,'twinkleTune.wav');

%% Spectral Content of the Signal
freqz(myTune,1,1024,fSampling);
spectrogram(myTune,quarterNote,4,1024,fSampling)