%% Script generates musical notes and then arranges them to create a
%  musical tune corresponding to a song. Noise is also added to create a
%  noisy version of the tune.

%% Choose Sampling Frequency 
fSampling = 4000;

%% Create Time Vector
t = 0:1/fSampling:1;

%% Set Note frequencies
fnote = [262 294 330 349 392 440 494]';

%% Create Notes data and organize into Columns so that each column is a single note
noteSamples = sin(2*pi*fnote*t);
noteSamples = noteSamples';

%% Create random exponential weight vectors for each note
expWtCnst = 6;
expWtVecs = exp(-abs(expWtCnst*t(ones(7,1),:)));
expWtVecs = expWtVecs';

% Weight the Notes and listen
noteSamples = noteSamples.*expWtVecs ;
%soundsc(noteSamples(:),fSampling)

%% Generate Tune
Do = 1;
Re = 2;
Mi = 3;
Fa = 4;
So = 5;
La = 6;
Ti = 7;

lTime = length(t);
lTime2 = ceil(lTime/2);
lTime3b4 = ceil(3*lTime/4);
lTime4 = ceil(lTime/4);
lTime8 = ceil(lTime/8);
myTune = [...
    noteSamples(1:lTime3b4,Do);noteSamples(1:lTime4,Re);noteSamples(1:lTime3b4,Mi);... % Do A Deer 
    noteSamples(1:lTime4,Do);noteSamples(1:lTime2,Mi);noteSamples(1:lTime2,Do);...% A female 
    noteSamples(:,Mi);... % Deer
    ...
    noteSamples(1:lTime3b4,Re);noteSamples(1:lTime4,Mi);...  % Re a
    noteSamples(1:lTime4,Fa);noteSamples(1:lTime4,Fa);noteSamples(1:lTime4,Mi);...  % drop of gold
    noteSamples(1:lTime4,Re);noteSamples(:,Fa);...% en sun   
    ...
    noteSamples(1:lTime3b4,Mi);noteSamples(1:lTime4,Fa);noteSamples(1:lTime3b4,So);... % Mi A Name
    noteSamples(1:lTime4,Mi);noteSamples(1:lTime2,So);noteSamples(1:lTime2,Mi);...% I call 
    noteSamples(:,So);... % Myself
    ...
    noteSamples(1:lTime3b4,Fa);noteSamples(1:lTime4,So);...  % Far a
    noteSamples(1:lTime4,La);noteSamples(1:lTime4,La);noteSamples(1:lTime4,So);...  % long long way
    noteSamples(1:lTime4,Fa);noteSamples(:,La)];%...% to run

soundsc(myTune,fSampling)

%% Generate Noisy notes and tune.
noisynoteSamples = noteSamples + .05*sin(2*pi*60*t(ones(7,1),:))'+ .05*sin(2*pi*120*t(ones(7,1),:))' + .25*sin(2*pi*1400*t(ones(7,1),:))';

noisyTune = [...
    noisynoteSamples(1:lTime3b4,Do);noisynoteSamples(1:lTime4,Re);noteSamples(1:lTime3b4,Mi);... % Do A Deer 
    noisynoteSamples(1:lTime4,Do);noisynoteSamples(1:lTime2,Mi);noteSamples(1:lTime2,Do);...% A female 
    noisynoteSamples(:,Mi);... % Deer
    ...
    noisynoteSamples(1:lTime3b4,Re);noisynoteSamples(1:lTime4,Mi);...  % Re a
    noisynoteSamples(1:lTime4,Fa);noisynoteSamples(1:lTime4,Fa);noisynoteSamples(1:lTime4,Mi);...  % drop of gold
    noisynoteSamples(1:lTime4,Re);noisynoteSamples(:,Fa);...% en sun   
    ...
    noisynoteSamples(1:lTime3b4,Mi);noisynoteSamples(1:lTime4,Fa);noisynoteSamples(1:lTime3b4,So);... % Mi A Name
    noisynoteSamples(1:lTime4,Mi);noisynoteSamples(1:lTime2,So);noisynoteSamples(1:lTime2,Mi);...% I call 
    noisynoteSamples(:,So);... % Myself
    ...
    noisynoteSamples(1:lTime3b4,Fa);noisynoteSamples(1:lTime4,So);...  % Far a
    noisynoteSamples(1:lTime4,La);noisynoteSamples(1:lTime4,La);noisynoteSamples(1:lTime4,So);...  % long long way
    noisynoteSamples(1:lTime4,Fa);noisynoteSamples(:,La)];%...% to run

soundsc(noisyTune,fSampling)

%% Save files
save('doremiTune.mat','myTune','fSampling');
wavwrite(myTune,fSampling,'doremiTune.wav')

save('doremiNoisyTune.mat','noisyTune','fSampling');
wavwrite(noisyTune,fSampling,'doreminoisyTune.wav')