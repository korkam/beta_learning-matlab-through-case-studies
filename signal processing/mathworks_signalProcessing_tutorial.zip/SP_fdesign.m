%% Designing a FIR filter using fdesign object.
% fdesign objects and associated methods provide a versatile approach to
% designing filters in MATLAB under the object oriented paradigm. The 
% fdesign object contains the complete filter specification. The final 
% filter design is achieved by invoking specialized methods for the fdesign 
% class.

close all
clear all

%% Set Analog Parameters
fStop1 = 2500;
fPass1 = 2700;
fPass2 = 4300;
fStop2 = 4500;
Rp = 1;
Rs = 60;
fSampling = 22050;
fNyquist = fSampling/2;

%% Create filter specification object, d, with default specs
% Note: To view available response types at the prompt try >> doc fdesign/responses
d = fdesign.bandpass;

%% Determine supported specification sets
set(d,'specification')

%% Apply specification set
setspecs(d,'Fst1,Fp1,Fp2,Fst2,Ast1,Ap,Ast2',fStop1,fPass1,fPass2,fStop2,Rs,Rp,Rs,fSampling);

%% View list of design methods available: 
designmethods(d)

%% Choose design algorithm and design the filter
Hd = design(d,'equiripple');

%% Analyze designed filter
fvtool(Hd);

%% Apply designed filter 
% Load tune, plot spectrum, listen to tune, filter tune and listen and plot
% spectrum. The file has a variable with the tune samples. The sampling 
% frequency is identical to that of the filter above.
x = wavread('myRecord.wav');
y = filter(Hd,x);

%% Listen to input signal
soundsc(x,fSampling);

%% Listen to output signal
soundsc(y,fSampling);