%% Design an stable IIR Filter for the mid-range of the five band
% equalizer. Direct conversion from the zero-pole form to transfer 
% function polynomial form  leads to instabilities. Instead, using dfilt
% objects and implementing the filter using second order sections after 
% obtaining the filter in zero-pole form makes the filter stable.

close all
clear all

%% Set Analog Parameters
fStop1 = 500;
fPass1 = 900;
fPass2 = 2500;
fStop2 = 3000;

Rp = 1;
Rs = 60;

%% Normalize Frequencies with respect to Nyquist Frequency
fSampling = 22050;
fNyquist = fSampling/2;

Ws = [fStop1 fStop2]/fNyquist;
Wp = [fPass1 fPass2]/fNyquist;

%% Design Butterworth Filter
[nB,WnB] = buttord(Wp,Ws,Rp,Rs)
[numB,denB] = butter(nB,WnB);

%% Design of a Stable Butterworth Filter
[z,p,k] = butter(nB,WnB);
[sos,g] = zp2sos(z,p,k);
h = dfilt.df2sos(sos,g);
fvtool(h,'Analysis','PoleZero')
