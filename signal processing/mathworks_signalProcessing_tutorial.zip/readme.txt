Directions for installing the Signal Processing Tutorial files in MATLAB.

1) If not yet done, download the �signalProcessing_tutorial.zip� file from the tutorial player Appendix, or the examples link under the subheading, Tutorial Appendix, on the main Signal Processing tutorial launch pad.

2) Once you have downloaded the ZIP-file, place it in the default MATLAB work directory, usually a directory called MATLAB under your root �Documents� directory of your machine.

3) Extract the example files from the ZIP-file into this directory. The ZIP-file will extract the files into a new subdirectory named, �signalProcessing_tutorial�. 

4) Start MATLAB and change directory using the Change Directory Browser to the �signalProcessing_tutorial� folder that you just extracted.

5) Once complete, you should see the files in the tutorial directory in the Current Directory Browser of MATLAB.