classdef Data1d
% Copyright 2016
% The MathWorks, Inc.

    properties
        XData
        YData
        ShowHokan = false
        HokanType = 'linear'
    end
    
end