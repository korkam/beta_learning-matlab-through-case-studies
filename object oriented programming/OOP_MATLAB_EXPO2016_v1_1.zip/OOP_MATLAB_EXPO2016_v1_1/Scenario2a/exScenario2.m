% Copyright 2016
% The MathWorks, Inc.

%% 1
clear
close all
clc
x = 0:10;
y = sin(x);

obj = Data1d;
obj.XData = x;
obj.YData = y;
plot(obj)

%% MATLAB plot
figure
plot(x,y)
title('MATLAB Plot')
