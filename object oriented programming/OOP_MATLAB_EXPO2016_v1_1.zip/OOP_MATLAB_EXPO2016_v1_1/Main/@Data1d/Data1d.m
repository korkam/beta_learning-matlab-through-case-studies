classdef Data1d < DataClass
% Copyright 2016
% The MathWorks, Inc.
    
    properties (Dependent)
        X
        Data
    end
    
    properties (Constant,Hidden)
        AllowableInterpMethods = {'linear','nearest','pchip','spline'}
    end
    
    methods
        function obj = Data1d(x,data)
            [x,data] = checkInput(obj,x,data);
            obj.NumIndependentVariables = 1;
            obj.X = x;
            obj.Data = data;
        end
        
        function set.X(obj,val)
            obj.RawData(:,1) = val;
        end
        
        function val = get.X(obj)
            val = obj.RawData(:,1);
        end
        
        function set.Data(obj,val)
            obj.RawData(:,2) = val;
        end
        
        function val = get.Data(obj)
            val = obj.RawData(:,2);
        end
                                
    end
    
end