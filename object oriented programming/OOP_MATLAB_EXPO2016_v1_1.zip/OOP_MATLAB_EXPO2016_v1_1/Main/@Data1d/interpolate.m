function out = interpolate(obj,val)
% Copyright 2016
% The MathWorks, Inc.

[sortedX,idx] = sort(obj.X);
sortedD = obj.Data(idx);
out = interp1(sortedX,sortedD,val,obj.InterpMethod);
end
