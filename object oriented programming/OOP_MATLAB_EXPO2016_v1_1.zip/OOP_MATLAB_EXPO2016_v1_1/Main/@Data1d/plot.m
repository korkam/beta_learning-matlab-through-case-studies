function plot(obj,hAx)
% Copyright 2016
% The MathWorks, Inc.

if nargin == 1
    hAx = gca;
end

obj.hInterp = plot(hAx,NaN,NaN,'r','LineWidth',2,'HitTest','off','Visible','off');
hold(hAx,'on')
obj.hData = plot(hAx,NaN,NaN,'bo','LineWidth',2,'MarkerFaceColor','b');
hold(hAx,'off')

updateDataPlot(obj)
toggleInterp(obj)

ln(1) = event.proplistener(obj,findprop(obj,'InterpMethod'),'PostSet',@updateInterpPlot);
ln(2) = event.proplistener(obj,findprop(obj,'ShowInterp'),'PostSet',@obj.toggleInterp);
ln(3) = event.proplistener(obj,findprop(obj,'RawData'),'PostSet',@updateDataPlot);

obj.hData.UserData = ln;

    function updateDataPlot(varargin)
        %disp('updateDataPlot')
        obj.hData.XData = obj.X;
        obj.hData.YData = obj.Data;
        updateInterpPlot(obj)
    end

    function updateInterpPlot(varargin)
        %disp('updateInterpPlot')
        obj.hInterp.XData = linspace(min(obj.X),max(obj.X),500);
        obj.hInterp.YData = interpolate(obj,obj.hInterp.XData);
    end

end
