classdef Data2d < DataClass
% Copyright 2016
% The MathWorks, Inc.
    
    properties (Dependent)
        X
        Y
        Data
    end
    
    properties
        InterpolantObject
    end
    
    properties
        DirtyData = true
    end
    
    properties (Constant)
        AllowableInterpMethods = {'linear','nearest','natural'}
    end
    
    methods
        function obj = Data2d(x,y,data)
            [x,y,data] = checkInput(obj,x,y,data);
            obj.NumIndependentVariables = 2;
            obj.X = x;
            obj.Y = y;
            obj.Data = data;
            
            addlistener(obj,{'RawData','InterpMethod'},'PostSet',@obj.dataChanged);
        end
        
        function set.X(obj,val)
            obj.RawData(:,1) = val;
        end
        
        function val = get.X(obj)
            val = obj.RawData(:,1);
        end
        
        function set.Y(obj,val)
            obj.RawData(:,2) = val;
        end
        
        function val = get.Y(obj)
            val = obj.RawData(:,2);
        end
        
        function set.Data(obj,val)
            obj.RawData(:,3) = val;
        end
        
        function val = get.Data(obj)
            val = obj.RawData(:,3);
        end
        
        function dataChanged(obj,varargin)
            obj.DirtyData = true;
        end
        
    end
    
end