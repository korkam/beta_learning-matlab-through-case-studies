function plot(obj,hAx)
% Copyright 2016
% The MathWorks, Inc.

if nargin == 1
    hAx = gca;
end

obj.hInterp = surf(hAx,[],[],[],'HitTest','off','EdgeColor','none','Visible','off');
hold(hAx,'on')
[~,obj.hInterp(2)] = contour3(hAx,[],[],[],'HitTest','off','EdgeColor','k','Visible','off');
obj.hData = scatter3(hAx,NaN,NaN,NaN);
hold(hAx,'off')

view(3)

updateDataPlot(obj)
toggleInterp(obj)

ln(1) = event.proplistener(obj,findprop(obj,'InterpMethod'),'PostSet',@updateInterpPlot);
ln(2) = event.proplistener(obj,findprop(obj,'ShowInterp'),'PostSet',@obj.toggleInterp);
ln(3) = event.proplistener(obj,findprop(obj,'RawData'),'PostSet',@updateDataPlot);

obj.hData.UserData = ln;

    function updateDataPlot(varargin)
        %disp('updateDataPlot')
        obj.hData.XData = obj.X;
        obj.hData.YData = obj.Y;
        obj.hData.ZData = obj.Data;
        obj.hData.CData = obj.Data;
        updateInterpPlot(obj)
    end

    function updateInterpPlot(varargin)
        obj.DirtyData = true;
        %disp('updateInterpPlot')
        xd = linspace(min(obj.X),max(obj.X),500);
        yd = linspace(min(obj.Y),max(obj.Y),500);
        [Xgrid,Ygrid] = meshgrid(xd,yd);
        zd = interpolate(obj,Xgrid,Ygrid);
        
        set(obj.hInterp,'XData',xd,'YData',yd,'ZData',zd);
        obj.hInterp(1).CData = zd;
    end

end
