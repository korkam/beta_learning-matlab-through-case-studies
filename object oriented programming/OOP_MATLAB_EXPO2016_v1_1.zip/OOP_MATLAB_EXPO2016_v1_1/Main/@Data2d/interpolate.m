function out = interpolate(obj,valX,valY)
% Copyright 2016
% The MathWorks, Inc.

if obj.DirtyData
    obj.InterpolantObject = scatteredInterpolant(obj.X,obj.Y,obj.Data,obj.InterpMethod);
    obj.DirtyData = false;
end
out = obj.InterpolantObject(valX,valY);
end
