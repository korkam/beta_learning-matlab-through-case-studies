function addDraggablePoints(obj)
% Copyright 2016
% The MathWorks, Inc.

% v1.1 (Nov 5, 2016)
%      Changed code to use bsxfun, instead of implicit expansion.

obj.DataObj.hData.ButtonDownFcn = @clickPt;
obj.AppHandles.Fig1.WindowButtonUpFcn = @unclickPt;

    function clickPt(varargin)
        pt = obj.AppHandles.Axes.CurrentPoint;
        
        if obj.DataObj.NumIndependentVariables == 1
            sz = size(obj.DataObj.RawData,1);
            %num = cross([obj.DataObj.RawData zeros(sz,1)]-pt(1,:),[obj.DataObj.RawData zeros(sz,1)]-pt(2,:));
            num = cross(bsxfun(@minus,[obj.DataObj.RawData zeros(sz,1)],pt(1,:)),bsxfun(@minus,[obj.DataObj.RawData zeros(sz,1)],pt(2,:)));
            num = arrayfun(@(x) norm(num(x,:)), 1:sz);
            den = norm(pt(2,:) - pt(1,:));
            d = num / den;
        elseif obj.DataObj.NumIndependentVariables == 2
            %num = cross(obj.DataObj.RawData-pt(1,:),obj.DataObj.RawData-pt(2,:));
            num = cross(bsxfun(@minus,obj.DataObj.RawData,pt(1,:)),bsxfun(@minus,obj.DataObj.RawData,pt(2,:)));
            num = arrayfun(@(x) norm(num(x,:)), 1:size(num,1));
            den = norm(pt(2,:) - pt(1,:));
            d = num / den;
        end
        
        [~,id] = min(d);
        
        %         if obj.DataObj.NumIndependentVariables == 1
        %             [~,id] = min(sqrt((obj.DataObj.hData.XData - mean(pt(:,1))).^2 + (obj.DataObj.hData.YData - mean(pt(:,2))).^2));
        %         elseif obj.DataObj.NumIndependentVariables == 2
        %             [~,id] = min(sqrt((obj.DataObj.hData.XData - mean(pt(:,1))).^2 + (obj.DataObj.hData.YData - mean(pt(:,2))).^2 + (obj.DataObj.hData.ZData - mean(pt(:,3))).^2));
        %         end
        obj.AppHandles.Fig1.WindowButtonMotionFcn = {@movePt,id};
        
        axis(obj.AppHandles.Axes,'manual')
    end

    function movePt(~,~,id)
        pt = obj.AppHandles.Axes.CurrentPoint;
        val = mean(pt);
        if obj.DataObj.NumIndependentVariables == 1
            obj.DataObj.RawData(id,:) = val(1:2);
        elseif obj.DataObj.NumIndependentVariables == 2
            obj.DataObj.RawData(id,:) = val;
        end
    end

    function unclickPt(varargin)
        obj.AppHandles.Fig1.WindowButtonMotionFcn = '';
        axis(obj.AppHandles.Axes,'auto')
    end

end