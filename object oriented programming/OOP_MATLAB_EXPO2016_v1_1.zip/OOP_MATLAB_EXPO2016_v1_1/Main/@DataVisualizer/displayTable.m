function displayTable(obj)
% Copyright 2016
% The MathWorks, Inc.

if obj.DataObj.NumIndependentVariables == 1
    obj.AppHandles.Table.ColumnName = {'X','Y'};
    obj.AppHandles.Table.ColumnWidth = {150,150};
    obj.AppHandles.Table.ColumnEditable = true(1,2);
    obj.AppHandles.Table.ColumnFormat = {'numeric','numeric'};
else
    obj.AppHandles.Table.ColumnName = {'X','Y','Z'};
    obj.AppHandles.Table.ColumnWidth = {150,150,150};
    obj.AppHandles.Table.ColumnEditable = true(1,3);
    obj.AppHandles.Table.ColumnFormat = {'numeric','numeric','numeric'};
end
updateTable(obj)

end