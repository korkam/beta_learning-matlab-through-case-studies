function updateTable(obj,varargin)
% Copyright 2016
% The MathWorks, Inc.

if obj.DataObj.NumIndependentVariables == 1
    data = [obj.DataObj.X(:) obj.DataObj.Data(:)];
else
    data = [obj.DataObj.X(:) obj.DataObj.Y(:) obj.DataObj.Data(:)];
end
obj.AppHandles.Table.Data = data;

end