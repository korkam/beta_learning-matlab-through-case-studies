classdef DataVisualizer < handle
% Copyright 2016
% The MathWorks, Inc.

    properties
        AppHandles
        DataObj
    end
    
    methods
        function obj = DataVisualizer
            
            initApp(obj)
            
        end
        
        initApp(obj)
        
    end
    
    methods (Access = protected)
        addDraggablePoints(obj)
    end
    
end