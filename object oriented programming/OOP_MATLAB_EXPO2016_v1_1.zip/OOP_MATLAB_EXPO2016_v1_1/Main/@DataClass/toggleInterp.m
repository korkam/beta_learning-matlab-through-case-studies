function toggleInterp(obj,varargin)
% Copyright 2016
% The MathWorks, Inc.

%disp('toggleInterp')
if obj.ShowInterp
    set(obj.hInterp,'Visible','on');
else
    set(obj.hInterp,'Visible','off');
end
end
