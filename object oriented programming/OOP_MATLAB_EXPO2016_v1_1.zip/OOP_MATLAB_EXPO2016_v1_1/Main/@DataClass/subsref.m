function out = subsref(obj,S)
% Copyright 2016
% The MathWorks, Inc.

switch S(1).type
    case '()'
        if length(S(1).subs) ~= obj.NumIndependentVariables
            error('�Ɨ��ϐ��� %d �łȂ���΂Ȃ�܂���B', obj.NumIndependentVariables)
        end
        out = interpolate(obj,S(1).subs{:});
    case '.'
        if isprop(obj,S(1).subs)
            if length(S) > 1
                out = subsref(obj.(S(1).subs),S(2:end));
            else
                out = obj.(S(1).subs);
            end
        else
            error('Dot notation is only supported for accessing properties')
        end
    case '{}'
        error('{} is not supported')
end
end
