classdef (Abstract) DataClass < handle
% Copyright 2016
% The MathWorks, Inc.
    
    properties (SetObservable,AbortSet)
        InterpMethod = 'linear'
        ShowInterp = false
        Colormap = 'parula';
    end
    properties (Hidden,SetObservable,AbortSet)
       RawData 
    end
    properties (Hidden)
        NumIndependentVariables
        hData
        hInterp
    end
    
    properties (Abstract, Constant, Hidden)
        AllowableInterpMethods
    end
    
    methods
        function set.InterpMethod(obj,method)
            obj.InterpMethod = validatestring(method,obj.AllowableInterpMethods);
        end
        
        function set.ShowInterp(obj,value)
            validateattributes(value,{'logical'},{'scalar'})
            obj.ShowInterp = value;
        end
        
    end
end