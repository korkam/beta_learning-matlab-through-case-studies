function runApp()

% Copyright 2016
% The MathWorks, Inc.

DataVisualizer;

end