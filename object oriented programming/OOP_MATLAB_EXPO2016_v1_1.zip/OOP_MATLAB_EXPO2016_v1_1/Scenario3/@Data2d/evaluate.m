function out = evaluate(obj,xVal,yVal)
% Copyright 2016
% The MathWorks, Inc.

% for Data2d

out = griddata(obj.XData,obj.YData,obj.ZData,xVal,yVal,obj.HokanType);

end