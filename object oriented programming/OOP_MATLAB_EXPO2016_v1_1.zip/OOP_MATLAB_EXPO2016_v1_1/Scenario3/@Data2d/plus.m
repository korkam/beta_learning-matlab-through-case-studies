function out = plus(obj1,obj2)
% Copyright 2016
% The MathWorks, Inc.

out = Data2d([obj1.XData(:);obj2.XData(:)],[obj1.YData(:);obj2.YData(:)],[obj1.ZData(:);obj2.ZData(:)]);

end