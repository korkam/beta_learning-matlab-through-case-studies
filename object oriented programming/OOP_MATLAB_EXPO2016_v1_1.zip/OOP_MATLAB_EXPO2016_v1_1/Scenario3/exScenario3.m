% Copyright 2016
% The MathWorks, Inc.

%% 1
clear
close all
clc
x = 0:10;
y = sin(x);

obj1 = Data1d(x,y);

%%
obj1.ShowHokan = true;
plot(obj1)

%% 2
clear
[X,Y,Z] = peaks(49);
n = randperm(49*49,50)';
[~,id] = max(Z(n));
obj2 = Data2d(X(n),Y(n),Z(n));

%%
plot(obj2)

%%
obj2.HokanType = 'natural';
obj2.ShowHokan = true;
plot(obj2)

%%
obj2(2,2.5)