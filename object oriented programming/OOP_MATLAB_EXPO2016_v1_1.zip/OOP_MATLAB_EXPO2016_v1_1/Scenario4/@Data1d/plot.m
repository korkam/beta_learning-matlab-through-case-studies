function plot(obj,varargin)
% Copyright 2016
% The MathWorks, Inc.

% �f�[�^�̉���

scatter(obj.XData,obj.YData,'filled')
xlabel('X')
ylabel('Y')

% ShowHokan == true �̂Ƃ���ԃf�[�^��\������
if obj.ShowHokan
    xs = linspace(min(obj.XData),max(obj.XData));
    ys = evaluate(obj,xs);
    
    hold on
    plot(xs,ys)
    hold off
    legend('�f�[�^','��ԃf�[�^')
end

if isempty(obj.Listener)
    obj.Listener = addlistener(obj,{'XData','YData','HokanType','ShowHokan'},...
        'PostSet',@obj.plot);
end

set(gca,'DeleteFcn',@axesBeingDeleted)

    function axesBeingDeleted(varargin)
        delete(obj.Listener)
        obj.Listener = [];
    end

end