% Copyright 2016
% The MathWorks, Inc.

%% 1
clear
close all
clc
x = 0:10;
y = sin(x);

obj1 = Data1d(x,y);
obj1.ShowHokan = true;
plot(obj1)

%%
obj1.YData(4) = -0.5;
%%
obj1.HokanType = 'spline';
%%
obj1.ShowHokan = false;
%%
obj1.ShowHokan = true;

%% 2
clear
close all
[X,Y,Z] = peaks(49);
n = randperm(49*49,50)';
dObj2 = Data2d(X(n),Y(n),Z(n));
dObj2.HokanType = 'natural';
dObj2.ShowHokan = true;
plot(dObj2)

%%
dObj2.HokanType = 'linear';
%%
dObj2.ShowHokan = false;
%%
dObj2.ShowHokan = true;
%%
[~,id] = min(dObj2.ZData);
dObj2.ZData(id) = 8;
%%
dObj2.ZData(id) = 0;