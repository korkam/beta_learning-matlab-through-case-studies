function plot(obj,varargin)
% Copyright 2016
% The MathWorks, Inc.

% �f�[�^�̉���

scatter3(obj.XData,obj.YData,obj.ZData,[],obj.ZData,'filled')
xlabel('X')
ylabel('Y')
zlabel('Z')
axis tight

% ShowHokan == true �̂Ƃ���ԃf�[�^��\������
if obj.ShowHokan
    [xGrid,yGrid] = meshgrid(linspace(min(obj.XData),max(obj.XData),20),linspace(min(obj.YData),max(obj.YData),20));
    zGrid = evaluate(obj,xGrid,yGrid);
    
    hold on
    surf(xGrid,yGrid,zGrid,'EdgeAlpha',.25)
    hold off
    legend('�f�[�^','��ԃf�[�^')
end

if isempty(obj.Listener)
    obj.Listener = addlistener(obj,{'XData','YData','ZData','HokanType','ShowHokan'},...
        'PostSet',@obj.plot);
end

set(gca,'DeleteFcn',@axesBeingDeleted)

    function axesBeingDeleted(varargin)
        delete(obj.Listener)
        obj.Listener = [];
    end

end