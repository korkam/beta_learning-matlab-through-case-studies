% Copyright 2016
% The MathWorks, Inc.

clear
close all
clc
x = [1 3 7 9];
y = [5 5 2 3];

obj = Data1d

%%
obj.XData = x;
obj.YData = y;
obj
%%
plotData(obj)

%%
obj.YData(2) = 4;
plotData(obj)

%%
y1 = evaluate(obj,5)
%%
obj.HokanType = 'spline';
y2 = evaluate(obj,5)
%%
obj.ShowHokan = true;
plotData(obj)