function out = evaluate(obj,val)
% Copyright 2016
% The MathWorks, Inc.

% �f�[�^�̕��

out = interp1(obj.XData,obj.YData,val,obj.HokanType);

end