This entry contains the demo shown at the MATLAB Expo 2016 in Japan (Oct 19, 2016), session titled "Object-oriented programming for creating applications."

Main:
Main application - Visual Data Editor. Run the app by running "runApp". The application loads 1-D or 2-D data stored in a CSV file, and displays the data on the graph and in a table. You can interactively move the data points, as well as change the data from the table. There is an option to display the interpolated line.

Scenario1:
A simple example of a class with just properties.

Scenario2a:
A simple example of a class with properties and methods

Scenario2b:
An example of a class with subsref() and plus() defined for a custom behavior.

Scenario3:
An example of a class that inherits from another class.

Scenario4:
An example of events and listeners.