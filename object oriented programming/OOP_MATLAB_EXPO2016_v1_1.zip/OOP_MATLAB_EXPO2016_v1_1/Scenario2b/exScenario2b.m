% Copyright 2016
% The MathWorks, Inc.

%% 1
clear
close all
clc
x = 0:10;
y = sin(x);
obj = Data1d;
obj.XData = x;
obj.YData = y;

obj.ShowHokan = true;
plot(obj)
%%
obj(4.5)
%%
obj(2:8)

%% 2
obj1 = Data1d;
obj1.XData = [1 4 7 10];
obj1.YData = [2 6 4 8];
obj1.HokanType = 'spline';
obj1.ShowHokan = true;

obj2 = Data1d;
obj2.XData = [2 5 6 9];
obj2.YData = [4 3 4 7];
obj2.HokanType = 'spline';
obj2.ShowHokan = true;

figure
plot(obj1)
axis([1 10 2 8])
figure
plot(obj2)
axis([1 10 2 8])
%%
obj3 = obj1 + obj2;
obj3.HokanType = 'spline';
obj3.ShowHokan = true;
figure
plot(obj3)
axis([1 10 2 8])